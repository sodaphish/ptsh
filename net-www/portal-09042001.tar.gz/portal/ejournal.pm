package ejournal; 

$__version = "0.0.1";
$debug = 0; 




sub HashJournal( $$ ){

	my $file = pop;
	my $directory = pop;
	my $lastline = 0; 

	if( -e "$directory/$file" ){
		open( IN, "$directory/$file" ) or die "$!"; 
		while( my $line = <IN> ){
			chomp( $line ); 
			if( $line eq "-----" ){ $lastline = 1; }
			elsif( $lastline == 1 ){
				$JournalEntries{'date'} = "$line"; 
				$lastline = 0; 
			} else {
				$JournalEntries{'entry'} .= "$line"; 
			}
		}
		close( IN );
	} else {
		PrintError( "Journal Not Found", "The journal you specified was not located." );
	}

}




sub WriteEntry( $$$ ){

	my $entry = pop;
	my $file = pop;
	my $directory = pop;
	my $date = `date +"%B %d %Y"`; chomp( $date );  
	my $time = `date +%r`; chomp( $time ); 

	print "$directory/$file<br><br>$entry" if( $debug ); 
	if( -e "$directory/$file" and -w "$directory/$file" ){

		open( OUT, ">>$directory/$file" ) or die "$!"; 
		print OUT "-----\n$date - $time\n$entry\n";
		close( OUT );

	} else {

		open( OUT, ">$directory/$file" ) or die "$!";
		print OUT "-----\n$date - $time\n$entry\n";
		close( OUT ); 

	}

	print "Your submission has been recieved..."; 

}




sub ViewJournal( $$ ){

	my $file = pop;
	my $directory = pop;
	my $lastline = 0; 

	print "$directory/$file<br>\n" if( $debug );

	if( -e "$directory/$file" ){
		print "<h1><font size=+3>Viewing $file</font></h1>\n\n"; 
		open( IN, "$directory/$file" ) or die "$!"; 
		while( my $line = <IN> ){
			chomp( $line ); 
			if( $line eq "-----" ){ $lastline = 1; }
			elsif( $lastline == 1 ){
				print "<b>$line</b><br>\n"; 
				$lastline = 0; 
			} else {
				print "<p>$line</p>\n"; 
			}
		}
		close( IN ); 
	} else {

		PrintError( "Specified journal not found", "The journal you have specified does not exist." );

	}

}





sub ListJournals( $ ){

	my $directory = pop( @_ ); 
	if( -x $directory and -d $directory and -e $directory ){

		my( @files ) = `ls -t1 --color=no $directory/*.jrnl`; 
		foreach my $_file ( @files ){
			chomp( $_file ); 
			print "$_file<br>\n";
		}

	} else {

		PrintError( "Specified directory not found.", "The directory you specified does not exist on this system, please adjust your configurations." ); 
	}

}






sub PrintError( $, $ ){

	my $text = pop;
	my $title = pop;

	print "<h1>$title</h1>\n$text<hr>ejournal $__version\n"; 

}


1; 
