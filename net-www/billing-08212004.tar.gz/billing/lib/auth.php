<?php

function sessionActive( $sid )
{
	//this is a stub for now.
	if( $sid )
	{
		return 1;
	}
}

?>
