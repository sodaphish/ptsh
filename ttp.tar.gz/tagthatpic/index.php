<?php 
include_once( "etc/siteConfig.php" );
include_once( "libs/libCommon.php" );

$s_->assign('t_title', "TagThatPic");
$s_->assign('t_name', 'coming soon');


$m = getParameter( "m" );


switch( $m ){
	# module controller
	case 'blah':
		include( "mod_blah.php" );
		break;
	default:
		$s_->display("$callerShort_.tpl");
		break;
}

$logger_->debug( "$callerShort_ __END__" );
?>
