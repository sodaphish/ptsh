<?php
/*
 * siteConfig.php - site-wide configuration
 *
 * Noteworthy aspects:
 * - $e_ allows you to control some very basic aspects between test and production
 * - this sets up the logger facility
 *
 */


# these are our global values
$e_ = array();
$e_['env'] = 'tst'; //set this to "pro" for production mode
$e_['tst_email'] = "coreyjsteele@gmail.com";
$e_['tst_dbhost'] = "localhost";
$e_['tst_dbuser'] = "root";
$e_['tst_dbpass'] = "ahh-ahs";
$e_['tst_dbname'] = "tagthatpic";
$e_['tst_rootdir'] = "/var/www/tagthatpic/";
$e_['pro_email'] = "support@tagthatpic.com";
$e_['pro_dbhost'] = "localhost";
$e_['pro_dbuser'] = "hostedby_tagthatpic";
$e_['pro_dbpass'] = "hostedby_tagthat";
$e_['pro_dbname'] = "ttp!@";
$e_['pro_rootdir'] = "/home/hostedby/public_html/tagthatpic/";
//TODO: make the site config use the $e_ array for fixed settings

#
# globals (all globals must end in a _ )
$rootDir_ = $e_[ $e_['env'] . "_rootdir" ];
$theme_ = 'default'; 
$caller_ = $_SERVER['PHP_SELF']; 
$callerShort_ = basename( $caller_, ".php" );

#
# includes
include_once( "$rootDir_/libs/libCommon.php" );


#
# setup the logger
include_once( "$rootDir_/libs/Logging.php" );
$logger_ = new Logging( "f", "$rootDir_/logs/$callerShort_.log" );
$logger_->setLevel( "debug" );
$logger_->debug( "$callerShort_ __BEGIN__" );


#
# database connection
$db = mysql_connect( "localhost", "root", "ahh-ahs" );
mysql_select_db( "tagthatpic" );


# 
# setup smarty
include_once( "$rootDir_/libs/Smarty.class.php" );
$s_ = new Smarty();
$s_->template_dir = "$rootDir_/templates/$theme_";
$s_->compile_dir = "$rootDir_/templates_c";
$s_->cache_dir = "$rootDir_/cache";
$s_->config_dir = "$rootDir_/etc";


?>
