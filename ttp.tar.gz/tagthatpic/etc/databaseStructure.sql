-- phpMyAdmin SQL Dump
-- version 3.2.3deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 04, 2009 at 06:52 AM
-- Server version: 5.1.37
-- PHP Version: 5.2.11-2ubuntu1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `tagthatpic`
--

-- --------------------------------------------------------

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
CREATE TABLE IF NOT EXISTS `devices` (
`did` int(11) NOT NULL AUTO_INCREMENT,
`deviceID` char(16) NOT NULL,
`uid` int(11) NOT NULL,
PRIMARY KEY (`did`),
UNIQUE KEY `did` (`deviceID`),
KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE IF NOT EXISTS `images` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`uid` int(11) NOT NULL,
`filename` varchar(64) NOT NULL,
`size` int(11) NOT NULL,
`checksum` varchar(32) NOT NULL,
`localCTIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
`visible` tinyint(1) NOT NULL DEFAULT '1',
`image` blob NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
`sid` varchar(32) NOT NULL,
`did` int(11) NOT NULL,
`uid` int(11) NOT NULL,
`ip` int(11) NOT NULL,
`epoch` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
`lastAct` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
UNIQUE KEY `sid` (`sid`,`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tagclass`
--

DROP TABLE IF EXISTS `tagclass`;
CREATE TABLE IF NOT EXISTS `tagclass` (
`classID` int(11) NOT NULL AUTO_INCREMENT,
`class` varchar(64) NOT NULL,
PRIMARY KEY (`classID`),
UNIQUE KEY `class` (`class`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
CREATE TABLE IF NOT EXISTS `tags` (
`tid` int(11) NOT NULL AUTO_INCREMENT,
`tag` varchar(128) NOT NULL,
`classid` int(11) NOT NULL,
`uid` int(11) NOT NULL,
`visible` tinyint(1) NOT NULL,
PRIMARY KEY (`tid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
`userID` int(11) NOT NULL AUTO_INCREMENT,
`username` varchar(128) NOT NULL COMMENT 'email',
`password` char(32) NOT NULL COMMENT 'md5 of username+password',
`email` varchar(254) NOT NULL,
`locked` enum('y','n') NOT NULL DEFAULT 'n',
`displayname` varchar(64) NOT NULL,
`accountType` int(11) NOT NULL,
UNIQUE KEY `userID` (`userID`),
UNIQUE KEY `username` (`username`),
UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

