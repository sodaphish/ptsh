<?php
#include_once "/home/hostedby/public_html/tagthatpic/etc/siteConfig.php";
include_once "../etc/siteConfig.php";
include_once "$rootDir_/libs/libCommon.php";

$username = getParameter( 'username' );
$password = getParameter( 'password' );

if( $uid )
{
	$jr = array();
	$jr['uid'] = $uid; 
	$jr['birthday'] = date(time());
	$jr['version'] = '1.0';
	$logger_->debug( json_encode( $jr ) );
	print json_encode( $jr );
} else {
	print <<<EOF
<form method=post action=$callerShort_.php>
<input type=text name=uid><input type=submit value="unit's unique ID">
</form>
EOF;

}

$logger_->debug( "$callerShort_ __END__" );

?>
