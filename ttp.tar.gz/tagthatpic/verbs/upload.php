<?php

include_once( "../etc/siteConfig.php" );
include_once( $rootDir_ . "/libs/Image.php" );
include_once( $rootDir_ . "/libs/Session.php" );

//http://localhost/tagthatpic/verbs/upload.php?{%22image%22:{%22imagePath%22:%22/User/Blah.jpg%22,%22imageSize%22:%22256032%22,%22imageChecksum%22:%2223AB1240928ABCEF%22},%22imageData%22:%22blahblahblah%22}


//urldecode() is used to get rid of HTTP encoding of special chars
// QUERY_STRING is used so we don't care if we use POST or GET and don't have
// to have any variables/http clutter.  the "true" forces the return from
// json_decode to be an array
$jsonInput = json_decode( urldecode( $_SERVER["QUERY_STRING"]), true);


// we'll use an Image object to get the needed attributes recorded and into the db
$image = new Image();

$image->setCheckSum( $jsonInput['image']['imageChecksum'] );
$image->setFilename( $jsonInput['image']['imagePath'] );
$image->setImage( $jsonInput['imageData'] );
$image->setVisibleState( 1 );

print "<pre>";
$image->dump();
print "<br/>\n";
//ImagePath, ImageSize, ImageChecksum, ImageTimestamp
var_dump( $jsonInput );
print "</pre>";


?>