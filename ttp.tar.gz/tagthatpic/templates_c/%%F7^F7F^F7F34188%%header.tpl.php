<?php /* Smarty version 2.6.25, created on 2009-09-28 09:18:11
         compiled from header.tpl */ ?>
<html>
<head>
	<title><?php echo $this->_tpl_vars['t_title']; ?>
</title>
</head>
<body>