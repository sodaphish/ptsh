<?php /* Smarty version 2.6.25, created on 2009-09-27 22:40:03
         compiled from footer.tpl */ ?>
</body>
</html>