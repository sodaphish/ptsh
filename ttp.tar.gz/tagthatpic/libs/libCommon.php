<?php

if( $rootDir_ )
{
  include_once( "$rootDir_/etc/siteConfig.php" );
} else {
  include_once( "/var/www/tagthatpic/etc/siteConfig.php" );
}

function getParameter( $p ) 
{
	global $_GET;
	global $_POST;
	global $s_;

	$tmpVar = $_GET["$p"]; 
	if( array_key_exists( $p, $_GET ) )
	{
		$s_->assign( "$p"."_", $_GET["$p"] );
		return $_GET["$p"]; 
	} elseif( array_key_exists( $p, $_POST ) ){
		$s_->assign( "$p"."_", $_POST["$p"] );
		return $_POST["$p"]; 
	} 
	return false;
} #end getParameter()


?>
