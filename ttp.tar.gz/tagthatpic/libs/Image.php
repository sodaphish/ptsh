<?php
/*
 *  libs/Image.php
 *    - by C.J. Steele, coreyjsteele@gmail.com
 *
 *	(C)opyright 2009, TagThatPic.COM, all rights reserved.
 *  
 * provides an object oriented interface to the Images table and the ImageTags table
 *
 * TODO: implement Logging so we can use $logger_ to log consistently
 * TODO: create an ImageTags table and use TagLibrary class to integrate here
 *
 * CHANGELOG:
 *   - Nov. 29, 2009 - added dumpAsArray() and dumpAsJSON() routines
 *   - Nov. 27, 2009 - initial class written
 *
 */

include_once "TagLibrary.php";
//TODO: add $tags property and functions necessary to add/remove tags to its tagLibrary

class Image {
	private $imageID;
	private $uid = 0;  //we'll need to make sure we know images owned by 0 are orphans
	private $checksum;
	private $ctime;
	private $filename;
	private $visible = 1;
	private $image;
	private $imageSize = 0;

	public function __construct()
	{
		switch( func_num_args() )
		{
			case 1:
				//create the class based off of fetchImage( $arg )
				$this->fetchImage( func_get_arg(0) );
				break;
			case 3:
				//checksum, size, filename
				$this->setCtime( time() ); 
				$this->setChecksum( func_get_arg(0) );
				$this->setImageSize( func_get_arg(1) );
				$this->setFilename( func_get_arg(2) );
			default:
				//leave the structure uninitialized
		} //end switch

	} //end __construct()


	public function getImageID()
	{
		return $this->imageID;
	} //end getImageID()


	public function getUid()
	{
		return $this->uid;
	} //end getUid()


	public function getChecksum()
	{
		return $this->checksum; 
	} //end getChecksum()


	public function verifyChecksum()
	{
	} //end verifyChecksum()


	public function getFilename()
	{
		return $this->filename;
	} //end getFilename()


	public function getCtime()
	//returns a
	{
		return strftime( "%Y-%m-%d %T", $this->ctime );
	} //end getCtime()


	public function getVisibleState()
	{
		return $this->visible;
	} //end getVisibleState()


	public function getImage()
	{
		return $this->image;
	}  //end getImage()


	public function getImageSize()
	{
		return $this->imageSize;
	} //end getImageSize()


	protected function setImageID( $id )
	{
		//here is where we generate the image's ID.
		$this->imageID = $id;
	} //end setImageID()


	public function setUid( $uid )
	{
		$this->uid = $uid;
		return true;
	} //end setUid()


	public function setChecksum( $csum )
	{
		$this->checksum = $csum;
		return true;
	} //end setChecksum()


	public function setFilename( $name )
	{
		$this->filename = $name;
		return true;
	} //end setFilename()


	public function rename( $name )
	{
		$this->setFilename( $name );
		return true;
	} //end rename()


	public function setCtime( $time )
	{
		$this->ctime = $time;
		return true;
	} //end setCtime()


	public function setVisibleState( $state )
	{
		if( $state > 0 )
		{
			$state = true;
		} elseif( $state <= 0 ){
			$state = false;
		} //end if
		$this->visible = $state;
		return true;
	} //end setVisibleState()


	public function setImage( $data )
	{
		//TODO: support reading a file from disk OR a data stream
		$this->image = $data;
		return true;
	} //end setImage()


	public function setImageSize( $size )
	{
		$this->imageSize = $size;
		return true;
	} //end setImageSize()


	public function update()
	{
		if( $this->imageID )
		{
			$this->fetchImage( $this->imageID );
		} //end if
		return false;
	} //end update


	public function fetchImage()
	//fetches an image from the database based on the imageID and returns either
	// the image ID or false depending on success or failure (respectively)
	{
		$getThisID = func_get_arg( 0 );
		if( $getThisID > 0 )
		{
			//TODO: need to do error handling on this query
			$fetchStatement = "select id, uid, filename, size, checksum, localctime, visible, image from images where id=" . func_get_arg(0);
			$fetchStatementResult = mysql_query( $fetchStatement );
			list( $i, $u, $f, $s, $c, $l, $v, $img ) = mysql_fetch_row( $fetchStatementResult );

			//TODO: catch failures in these and make sure we handle them cleanly
			$this->setImageID( $i );
			$this->setUid( $u );
			$this->setFilename( $f );
			$this->setImageSize( $s );
			$this->setChecksum( $c );
			$this->setCtime( $l );
			$this->setVisibleState( $v );
			$this->setImage( $img );

			return $this->imageID;
		} else {
			return false;
		} //end if
	} //end fetchImage()


	public function storeImage()
	//stores an Image object in the images table for later retreival.  
	{
		//TODO: ensure that the Image is complete before writing it to the database
		$storeStatement;
		if( $this->imageID )
		{
			//updating an already saved image
			$storeStatement = "update images set uid=$this->uid, size=$this->imageSize, checksum='$this->checksum', localctime='" . $this->getCtime() . "', visible=$this->visible, image='$this->image', filename='$this->filename' where id=$this->imageID";
		} else {
			//a new image, do an insert
			$storeStatement = "insert into images ( uid, size, filename, checksum, localctime, visible, image ) values ( $this->uid, $this->imageSize, '$this->filename', '$this->checksum','". $this->getCtime() . "', $this->visible, '$this->image' )";
		} //end if
		$storeStatementResult = mysql_query( $storeStatement );
		if( $storeStatementResult )
		{
			$returnVal = mysql_insert_id();
			if( $returnVal )
			{
				$this->setImageID( $returnVal );
				return $returnVal;
			} elseif( $this->id ){
				return $this->id;
			} //end if
		} else {
			print $storeStatement . "\n";
			return false;
		} //end if 
	} //end storeImage()


	public function destroyImage()
	// an alias to the protected destroyByImageID() routine
	{
		return $this->destroyByImageID( $this->imageID );
	}


	protected function destroyByImageID( $id )
	//deletes an image from the database
	{
		//TODO: fixme -- doesn't APPEAR to be working in the testing suite.
		$destroyStatement = "delete from Images where id = $id";
		$destroyStatementResult = mysql_query( $destroyStatement );
		if( $destroyStatementResult )
		{
			//while we've deleted it from the database, we haven't purged its data.
			$this->setImageID( 0 );
			$this->setUid( 0 );
			$this->setFilename( "" );
			$this->setImageSize( 0 );
			$this->setChecksum( "" );
			$this->setCtime( "" );
			$this->setVisibleState( 0 );
			$this->setImage( "" );
			return true;
		}
		return false;
	} //end destroyByImageID()


	public function dump()
	{
		print "imageID  :" . $this->imageID . "\n";
		print "uid      :" . $this->uid . "\n";
		print "checksum :" . $this->checksum . "\n";
		print "ctime    :" . $this->ctime . "\n";
		print "filename :" . $this->filename . "\n";
		print "visible  :" . $this->visible . "\n";
		print "imageSize:" . $this->imageSize . "\n";
		print "image    :" . $this->image . "\n";
	} //end dump()


	public function dumpAsArray()
	{
		//TODO: write me
	} //end dumpAsArray()


	public function dumpAsJSON()
	{
		//TODO: write me
	} //end dumpAsJSON()


} //end Image
?>