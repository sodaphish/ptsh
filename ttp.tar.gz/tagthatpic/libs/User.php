<?php
/*  
 *  Users.php
 *    - by C.J. Steele, coreyjsteele@gmail.com
 * 
 * provides an object oriented interface to the users table.
 *
 * TODO: implement Logging so we can use $logger_ to log consistently
 *
 * CHANGELOG:
 *   - Nov. 26, 2009 - initial class completed
 */

class User {
	
	private $userID = 0; //their internally assigned userID
	private $username = ""; //their (upto) 128-byte username
	private $password = ""; //their 32byte hashed password
	private $locked = 0; //whether the account is locked (1) or not (0)
	private $displayName = ""; //the name they want to display to people
	private $email = ""; //the use's email address
	private $accountType = 0; //efault account type is "free"


	public function __construct()
	{
		// this is a disgusting hack because PHP doesn't know how to overload
		// constructors!!  When PHP introduces class overloading, I'll re-write
		switch( func_num_args() )
		{
			case 1:
				//the userid, so use fetchUser
				$this->fetchUserByID( func_get_arg(0) );
				break;
			case 2:
				//username & password
				$this->setUserName( func_get_arg(0) );
				$this->setPassword( func_get_arg(1) );
				break;
			case 3:
				//username, password & displayname
				$this->setUserName( func_get_arg(0) );
				$this->setPassword( func_get_arg(1) );
				$this->setDisplayName( func_get_arg(2) );
			case 4:
				//username, password, displayname and email address
				$this->setUsername( func_get_arg(0) );
				$this->setPassword( func_get_arg(1) );
				$this->setDisplayName( func_get_arg(2) );
				$this->setEmail( func_get_arg(3) );
				break;
		} //end switch
	} //end __construct()


	public function __destruct()
	{
		$this->storeUser();
	} //end __destruct()


	public function getUserID()
	{
		return $this->userID;
	} //end getUserID()


	public function getUserName()
	{
		return $this->username;
	} //end getUserName()

	
	public function getPassword()
	{
		return $this->password;
	} //end getPassword()


	public function getLockState()
	{
		return $this->locked;
	} //end getLockState()


	public function getDisplayName()
	{
		return $this->displayName;
	} //end getDisplayName()


	public function getAccountType()
	{
		return $this->accountType;
	} //end getAccountType()


	public function getEmail()
	{
		return $this->email;
	} //end getEmail()


	private function setUserID( $uid )
	// this is private because it is determined by the database.
	{
		$this->userID = $uid;
	} //end setUserID()


	public function setUserName( $username )
	{
		if( ! $this->locked )
		{
			//TODO: verify this is a legitimate email and not on our blacklist
			$this->username = $username;
			return true;
		} else {
			return false;
		}
	} //end setUserName()


	public function setPassword( $password )
	{
		if( ! $this->locked )
		{
			$this->password = $password; 
			return true;
		} else {
			return false;
		}	
	} //end setPassword()


	public function setDisplayName( $displayName )
	{
		if( ! $this->locked )
		{
			$this->displayName = $displayName;
			return true;
		} else {
			return false;
		}
	} //end setDisplayName()


	public function setLockState( $lockState )
	{
		if( ! $this->locked )
		{
			$this->locked = $lockState;
			return true;
		} else {
			return false;
		}
	}


	public function setEmail( $email )
	{
		//TODO: validate email address and validate that it isn't a duplicate
		$this->email = $email;
		return true;
	} //end setEmail()


	public function setAccountType( $type )
	{
		if( $type <= 0 )
		{
			$this->accountType = 0;
			return true;
		} elseif( $type == 1 ){
			$this->accountType = 1;
			return true;
		} elseif( $type >= 2 ){
			$this->accountType = 2;
			return true;
		} //end if
		//default to fail
		return false;
	} //end setAccountType()


	public function lock()
	{
		if( ! $this->locked )
		{
			$this->locked = 1;
			return true;
		} else {
			return false;
		}
	} //end lock()


	public function unlock()
	{
		if( $this->locked )
		{
			$this->locked =0; 
		} else {
			return false; 
		}
	} //end unlock()


	public function storeUser()
	{
		//if userID is > 0, then we're doing an update, otherwise we're doing an insert and returning the userID we get from MySQL
		$storeStatement = "";
		if( $this->userID > 0 )
		{
			$storeStatement = "update users set password='" . $this->password . "', displayName='" . $this->displayName . "', email='" . $this->email . "', accountType='" . $this->accountType . "' where uid=$this->uid";
		} else {
			$storeStatement = "insert into users ( username, password, displayname, email, accountType ) values ( '" . $this->username . "', '" . $this->password . "', '" . $this->displayName . "', '" . $this->email . "', '" . $this->accountType . "' )";
		} //end if
		// execute our storeStatement
		$storeResult = mysql_query( $storeStatement ) or die( mysql_error() );
		$returnValue;
		if( $storeResult )
		{
			$returnValue = mysql_insert_id();
			if( $returnValue )
			{
				$this->userID = $returnValue;
			} else {
			//TODO: raise an error?  Or query the database?
			}
		} else {
			// there was an error
			$returnValue = -1;
		} // end if
		return $returnValue;
	} //end storeUser()


	public function fetchUserByID( $uid )
	{
		if( ! $this->locked ) 
		{
			$fetchQuery = "select userid, username, password, displayname, locked, email, accountType from users where userid=$uid limit 1";
			$fetchQueryResult = mysql_query( $fetchQuery );
			if( $fetchQueryResult ) 
			{
				list( $uid, $un, $pw, $dn, $l, $e, $a ) = mysql_fetch_row( $fetchQueryResult );
				//TODO: we should be verifying that these return correctly.
				$this->setUserID( $uid );
				$this->setUserName( $un ); 
				$this->setPassword( $pw );
				$this->setDisplayName( $dn );
				$this->setLockState( $l );
				$this->setEmail( $e );
				$this->setAccountType( $a ); 
			} else {
				return false; 
			}
		} else {
			return false;
		}
	} //end fetchUserByID()


	public function fetchUserByName( $name )
	{
		$nameQuery = "select userid from users where username='$name'";
		$nameQueryResult = mysql_query( $nameQuery );
		if( $nameQueryResult )
		{
			list( $uid ) = mysql_fetch_row( $nameQueryResult );
			$this->fetchUserByID( $uid );
		}
		return false;
	} //end fetchUserByName()


	public function dump()
	{
		print "userID      :" . $this->userID . "\n";
		print "displayName :" . $this->displayName . "\n";
		print "username    :" . $this->username . "\n";
		print "password    :" . $this->password . "\n";
		print "email       :" . $this->email . "\n";
		print "accountType :" . $this->accountType . "\n";
		print "locked      :" . $this->locked . "\n";
	} //end dump()


	public function dumpAsArray()
	{
		//TODO: write me
	} //end dumpAsArray()


	public function dumpAsJSON()
	{
		//TODO: write me
	} //end dumpAsJSON()

	
}  //end User{}
?>