<?php
/*
 *  libs/TagLibrary.php
 *    - by C.J. Steele, coreyjsteele@gmail.com
 *
 *	(C)opyright 2009, TagThatPic.com, all rights reserved.
 *
 * provides an object oriented interface to the Tag table
 *
 * TODO: implement Logging so we can use $logger_ to log consistently
 *
 * CHANGELOG:
 *   - Nov. 28, 2009 - initial class written
 */

include_once "Tag.php";

class TagLibrary {

	private $tags = array();

	public function __construct()
	{
		//should be null
	} //end __construct()

	public function populateByImage()
	{
		$imageQuery = "select tid from ImageTags where imageID = " . func_get_args( 0 );
		$imageQueryResult = mysql_query( $imageQuery );

		if( $imageQueryResult )
		{
			//our query succeeded!
			while( list( $tid ) = mysql_fetch_row( $imageQueryResult ) )
			{
				$tag = new Tag( $tid );
				$this->tags.push( $tag );
			} //end while
			if( count( $this->tags ) )
			{
				return true;
			} else {
				return false;
			} //end if
		} else {
			return false;
		} //end if
	} //end populateByImage()

	public function populateByUser()
	{
		$imageQuery = "select tid from ImageTags where uid=" . func_get_args( 0 );
		$imageQueryResult = mysql_query( $imageQuery );
		if( $imageQueryResult )
		{
			//our query succeeded
			while( list( $tid ) = mysql_fetch_row( $imageQueryResult ) )
			{
				$tag = new Tag( $tid );
				$this->tags.push( $tag );
			} //end while
			if( count( $this->tags ) )
			{
				return true;
			} else {
				return false;
			} //end if
		} else {
			return false;
		} //end if
	} //end populateByUser()


	public function addTag()
	{
		//TODO: write me
		// this will need to support adding a tag by ID or creating a new tag on the fly
		// for newly created tags, make sure we manually call storeTag() so they get a tid.
	} //end addTag()


	public function removeTag( $tag )
	// this will only remove a tag by its TID.
	{
		//TODO: write me

	} //end removeTag()


	public function diff( $tagLibrary )
	{
		//allows us to differentiate between two tag libraries -- we'll return
		// two arrays: elements in common and elements that are dissimilar
		/*
		//TODO: write this/test it
		$matches = array();
		$disparates = array();
		foreach( $tagLibrary->dumpAsArray() as $tag )
		{
			//this gets our passed library into individual Tag elements
			foreach( $this->tags as $ourTag )
			{
				if( $tag->getTagID() == $ourTag->getTagID() )
				{
					//push this into our list of matching tags
				} else {
					//push this into our list of disparate tags
				}
			}
		}
		return( $matches, $disparates );
		*/
	} //end diff()


	public function dump()
	{
		foreach( $this->tags as $t )
		{
			$t->dump();
		} //end foreach
	} //end dump()

	
	public function dumpAsJSON()
	{
		return( json_encode( $this->dumpAsArray() ) );
	} //end dumpAsJSON()


	public function dumpAsArray()
	{
		$library = array();
		foreach( $this->tags as $t )
		{
			array_push( $library, $t->dumpAsArray() );
		} //end foreach
		return $library; //does this need to be wrapped?
	} //end dumpAsArray()

	
} //end TagLibrary

?>
