<?php
/*
 *  libs/Tag.php
 *    - by C.J. Steele, coreyjsteele@gmail.com
 *
 *	(C)opyright 2009, TagThatPic.com, all rights reserved.
 *
 * provides an object oriented interface to the Tag table
 *
 * TODO: implement Logging so we can use $logger_ to log consistently
 *
 * CHANGELOG:
 *   - Nov. 28, 2009 - initial class written
 */


class Tag {

	private $tagID;
	private $tag;
	private $classID;
	private $uid;
	private $visible;

	public function __construct()
	{
		switch( func_num_args() )
		{
			case 1:
				//just a tagID
				if( func_get_arg(0) > 0 )
				{
					$this->fetchTag( func_get_arg(0) );
				} //end if
				break;
			case 2:
				//tag and classID
				$this->tag = func_get_arg( 0 );
				$this->classID = func_get_arg( 1 );
				break;
			default:
				//none
		} //end switch
	} //end __construct()


	public function __destruct()
	{
		//default action is to save the tag.
		$this->storeTag();
	} //end __destruct()


	public function getTagID()
	{
		return $this->tagID;
	} //end getTagID()


	public function getTag()
	{
		return $this->tag;
	} //end getTag()


	public function getClassID()
	{
		return $this->classID;
	} //end getClassID()


	public function getUid()
	{
		return $this->uid;
	} //end getUid()


	public function getVisible()
	{
		return $this->visible;
	} //end getVisible()


	protected function setTagID( $id )
	//this is protected because it should only be done by the database.
	{
		$this->tagID = $id;
		return true;
	} //end setTagID()


	public function setTag( $tag )
	{
		//TODO: I hate hard-coding limits like this, so we need to figure out how to do it dynamically
		if( len( $tag ) < 128 )
		{
			$this->tag = $tag;
			return true;
		} else {
			return false;
		}
	} //end setTag()


	public function setClassID( $id )
	{
		if( $id > 0 )
		{
			$this->classID = $id;
			return true;
		} //end if
		return false;
	} //end setClassID()


	public function setUid( $uid )
	{
		if( $uid > 0 )
		{
			$this->uid = $uid;
			return true;
		} //end if
		return false;
	} //end setUid()


	public function setVisible( $visible )
	{
		if( $visible > 0 )
		{
			$this->visible = 1;
		} else {
			$this->visible = 0;
		} //end if
	} //end setVisible()


	public function storeTag()
	{
		$storeStatement;
		if( $this->tagID )
		{
			//this is an update of an existing tag
			$storeStatement = "update tags set tag='$this->tag', classid='$this->classID', uid='$this->uid', visible='$this->visible' where tid=$this->tagID";
		} else {
			//this is an insert of a new tag
			$storeStatement = "insert into tags ( tag, classid, uid, visible ) values ( '$this->tag', $this->classID, $this->uid, $this->visible )";
		} //end if
		$storeStatementResult = mysql_query( $storeStatement );
		if( $storeStatementResult )
		{
			//get insert ID and update $this->tagID
			$insertID = mysql_insert_id();
			if( $insertID )
			{
				$this->setTagID( $insertID );
			} else {
				$this->setTagID( $this->tagID );
			} //end if
			return true;
		} else {
			return false;
		} //end if
	} //end storeTag()


	public function fetchTag( $id )
	{
		$fetchQuery = "select tid, tag, classid, uid, visible from tags where tid=$id";
		$fetchQueryResult = mysql_query( $fetchQuery );
		if( $fetchQueryResult )
		{
			list( $tid, $tag, $classid, $uid, $visible ) = mysql_fetch_row( $fetchQueryResult );
			$this->setTagID( $tid );
			$this->setTag( $tag );
			$this->setClassID( $classid );
			$this->setUid( $uid );
			$this->setVisible( $visible ); 
			return true;
		} else {
			return false;
		} //end if
	} //end fetchTag()


	public function dump()
	{
		print "tagID   :" . $this->getTagID() . "\n";
		print "tag     :" . $this->getTag() . "\n";
		print "classID :" . $this->getClassID() . "\n";
		print "uid     :" . $this->getUid() . "\n";
	} //end dump()


	public function dumpAsArray()
	{
		$return = array();
		$return['tagID'] = $this->getTagID();
		$return['tag'] = $this->getTag();
		$return['classID'] = $this->getClassID();
		$return['uid'] = $this->getUid();
		return array( $return ); //do we need to wrap the array? I think so.
	} //end dumpAsArray()


	public function dumpAsJSON()
	{
		return json_encode( $this->dumpAsArray() );
	} //end dumpAsJSON()

} //end Tag

?>
