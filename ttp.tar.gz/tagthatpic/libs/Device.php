<?php
/*
 *  libs/Devices.php
 *    - by C.J. Steele, coreyjsteele@gmail.com
 *
 *	(C)opyright 2009, TagThatPic.COM, all rights reserved.
 *
 * provides an object oriented interface to the Devices table.
 *
 * TODO: implement Logging so we can use $logger_ to log consistently
 *
 * CHANGELOG:
 *   - Nov. 28, 2009 - initial class written
 */


class Device
{
	private $did;
	private $deviceID;
	private $uid;


	public function __construct()
	{
		//we'll need two constructors: one that creates a new device and the
		// other that fetches a device's record and builds the necessary object
		switch( func_num_args() )
		{
			case 1:
				//get the device ID from the database
				//
				//here, we overload the constructor to allow us to lookup a
				// device by did and by DeviceID (one is the alphanumeric, the
				// other numeric ID of the same device.)
				$buildOutID = func_get_arg( 0 );
				if( preg_match( '/\d*/', $buildOutID ) )
				{
					//its an all numeric ID
					$this->fetchDeviceByDID( $buildOutID );
				} else {
					//its an alphanumeric ID
					$this->fetchDeviceByDeviceID( $buildOutID );
				} //end if
				break;
			default:
				//by default, all we do is generate a deviceID and pray that \
				// PHP's rand() function doesn't vomit all over us.
				$this->setDeviceID( $this->generateDeviceID() );
		} //end switch
	} //end __construct()


	public function  __destruct()
	{
		// our default action will always be to store the device.
		$this->storeDevice();
	} //end __destruct()


	public function getDid()
	{
		return $this->did;
	} //end getDid()


	public function getDeviceID()
	{
		return $this->deviceID;
	} //end getDeviceID()


	public function getUid()
	{
		return $this->uid;
	} //end getUid()


	protected function setDid()
	//this is protected because the database should be the only thing assigning these.
	{
		$this->did = func_get_arg( 0 );
		return true;
	} //end setDid()


	public function setDeviceID()
	{
		$this->deviceID = func_get_arg(0);
		return true;
	} //end setDeviceID()


	public function setUid()
	{
		$this->uid = func_get_arg(0);
		return true;
	} //end setUid()


	protected function generateDeviceID()
	{
		$returnVal = "";
		for( $x = 0; $x < 16; $x++ )
		{
			//TODO: the rand() function periodically segfaults PHP 5.2.11, need to work around this somehow.
			$returnVal = $returnVal . chr( rand(65,90) );
		} //end for
		$redundancyQuery = "select did from devices where deviceid='$returnVal'";
		$redundancyQueryResult = mysql_query( $redundancyQuery );
		if( $redundancyQueryResult )
		{
			list( $did ) = mysql_fetch_row( $redundancyQueryResult );
			if( $did )
			{
				//this did is a dup!
				return -1;
			} //end if
		} //end if
		return $returnVal;
	} //end generateDeviceID()


	public function storeDevice()
	//stores the device in the devices table and returns a boolean success code
	{
		$storeDeviceQuery;
		if( $this->did )
		{
			//this will be an update
			$storeDeviceQuery = "udpate devices set deviceID='$this->deviceID', uid=$this->uid where did=$this->did";
		} else {
			//this is an insert
			$storeDeviceQuery = "insert into devices ( deviceID, uid ) values ( '$this->deviceID', $this->uid )";
		} //end if
		//TODO: handle these failures 
		$storeDeviceQueryResult = mysql_query( $storeDeviceQuery );
		if( $storeDeviceQueryResult )
		{
			//the store succeeded
			if( ! $this->did )
			{
				$this->setDid( mysql_insert_id() );
			}
			return true;
		} else {
			//the store failed!
			return false;
		} //end if
	} //end storeDevice()


	public function fetchDeviceByDeviceID( $deviceID )
	//populates the Device from the databse by the unique DeviceID
	{
		$fetchStatement = "select did, uid from devices where deviceid='$deviceID'";
		$fetchStatementResult = mysql_query( $fetchStatement );
		if( $fetchStatementResult )
		{
			//TODO: handle failures here gracefully
			list( $did, $uid ) = mysql_fetch_row( $fetchStatementResult );
 			$this->setDeviceID( $deviceID );
			$this->setDid( $did );
			$this->setUid( $uid );
			return true;
		} else {
			return false;
		} //end if
	} //end fetchDeviceByDeviceID()


	public function fetchDeviceByDID( $did )
	//populates the Device from the database by did (our predictable device ID)
	{
		$fetchStatement = "select deviceID, uid from devices where did='$did'";
		$fetchStatementResult = mysql_query( $fetchStatement );
		if( $fetchStatementResult )
		{
			//TODO: handle failures here gracefully
			list( $deviceid, $uid ) = mysql_fetch_row( $fetchStatementResult );
 			$this->setDeviceID( $deviceID );
			$this->setDid( $did );
			$this->setUid( $uid );
			return true;
		} else {
			return false;
		} //end if
	} //end fetchDeviceByDID()


	public function dump()
	{
		print "did      :" . $this->did . "\n";
		print "deviceID :" . $this->deviceID . "\n";
		print "uid      :" . $this->uid . "\n";
	} //end dump()


	public function dumpAsArray()
	{
		//TODO: write me
	} //end dumpAsArray()


	public function dumpAsJSON()
	{
		//TODO: write me
	} //end dumpAsJSON()
	

} //end Devices

?>