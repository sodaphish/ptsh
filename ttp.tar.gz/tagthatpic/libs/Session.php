<?php
/*
 *  libs/Session.php
 *    - by C.J. Steele, coreyjsteele@gmail.com
 *
 * provides an object oriented interface to the Sessions table.
 *
 * TODO: implement Logging so we can use $logger_ to log consistently
 *
 * CHANGELOG:
 *   - Nov. 26, 2009 - initial class written
 */

class Session
{
	private $sid; //session ID
	private $uid; //user ID
	private $did; //device ID
	private $ip; //ip of the session
	private $epoch; //date the session started
	private $lastact; //timestamp of the last activity of the session


	public function __construct()
	{
		//TODO: cleanup after PHP has constructor overloading
		switch( func_num_args() )
		{
			case 1:
				//the sessionID
				$this->fetchSession( func_get_arg(0) );
				break;
			case 3:
				//did, uid, ip
				$this->setSid();
				$this->setDid( func_get_arg(0) );
				$this->setUid( func_get_arg(1) );
				$this->setIP( func_get_arg(2) );
				$this->setEpoch();
				$this->setLastAct();
				break;
			default:
				//leave our properties uninitialized
				break;
		} //end switch
	} //end __construct()


	public function __destruct()
	{
		//we do not want a default action -- sessions need to be stored manually
	} //end __destruct()


	public function getSid()
	{
		return $this->sid;
	} //end getSid()


	public function getDid()
	{
		return $this->did;
	} //end getDid()


	public function getUid()
	{
		return $this->uid;
	} //end getUid()


	public function getIP()
	{
		return long2ip( $this->ip );
	} //end getIP()


	public function getEpoch()
	{
		return $this->epoch;
	} //end getEpoch()


	public function getLastAct()
	{
		return $this->lastact;
	} //end getLastAct()


	protected function setSid()
	//this is protected because the constructor should be the only caller, but classes derived from this may need to be able to call it directly
	{
		$sid;
		if( func_num_args() < 1 )
		{
			//no arguments specified, generate a sid and set it
			$sid = $this->generateSessionID();
		} else {
			$sid = func_get_arg( 0 );
		}
		$this->sid = $sid;
	} //end setSid()


	public function setDid( $did )
	{
		$this->did = $did;
	} //end setDid()


	public function setUid( $uid )
	{
		$this->uid = $uid;
	} //end setUid()


	public function setIP( $ip )
	{
		//TODO: fixme!  this thing is b0rked!
		if( ip2long( $ip ) > 0 )
		{
			$this->ip = ip2long( $ip );
			return true;
		} elseif( ip2long( long2ip( $ip ) ) ){
			$this->ip = $ip;
			return true;
		} else {
			return false;
		}
	} //end setIP()


	public function setEpoch()
	{
		if( func_num_args() < 1 )
		{
			$this->epoch = time();
		} else {
			$epoch = func_get_arg( 0 );
			//rudimentary validation of $epoch as a valid time()
			if( date( "%Y-%m-%d %T", $epoch ) )
			{
				$this->epoch = $epoch;
			} else {
				$this->epoch = time();
			} //end if
		} //end if
	} //end setEpoch()


	public function setLastAct()
	{
		if( func_num_args() < 1 )
		{
			$this->lastact = time();
		} else {
			$lastact = func_get_arg( 0 );
			//rudimentary validation of $lastact as a valid time()
			if( date( "%Y-%m-%d %T", $lastact ) )
			{
				$this->lastact = $lastact;
			} else {
				$this->lastact = time();
			}
		}
	} //end setLastAct()


	public function fetchSession( $sid )
	{
		//retrieve the specified session from the database & populate the object
		$sessionQuery = "select sid, did, uid, ip, epoch, lastact from sessions where sid='$sid'";
		$sessionQueryResult = mysql_query( $sessionQuery );
		if( $sessionQueryResult )
		{
			list( $s, $d, $u, $i, $e, $l ) = mysql_fetch_row( $sessionQueryResult );
			$this->setSid( $s );
			$this->setDid( $d );
			$this->setUid( $u );
			$this->setIP( $i );
			$this->setEpoch( $e );
			$this->setLastAct( $l );
		} else {
			return false;
		}
	} //end fetchSession()


	public function storeSession()
	{
		//write the session to the database
		$epoch = strftime( "%Y-%m-%d %T", $this->epoch ); //format our timestamp for mysql
		$lastact = strftime( "%Y-%m-%d %T", $this->lastact ); //format our timestamp for mysql
		$storeSessionStatement = "insert into sessions ( sid, did, uid, ip, epoch, lastact ) values ( '$this->sid', $this->did, $this->uid, '$this->ip', '$epoch', '$lastact' )";
		$storeSessionStatementResult = mysql_query( $storeSessionStatement ) or print mysql_error();
		if( $storeSessionStatementResult )
		{
			return true;
		} else {
			// there was an error
			$this->setSid( -1 );
		} // end if
		return false; //failsafe
	} //end storeSessions


	public function valid()
	{
		//TODO: validate $this against the database object and return a bool
	} //end valid()


	public function endSession()
	{
		//remove the $this->sid session from the database
		if( $this->sid )
		{
			$endSessionQuery = "delete from sessions where sid='$this->sid'";
			$endSessionQueryResult = mysql_query( $endSessionQuery );
			if( $endSessionQueryResult )
			{
				//we succeeded!
				return true;
			} else {
				//we failed
				return false;
			}
		}
	} //end endSession()


	private function generateSessionID()
	//generate a 32-byte session ID and verify it isn't in the database before returning it
	{
		$returnVal = "";
		for( $x = 0; $x < 32; $x++ )
		{
			//TODO: the rand() function periodically segfaults PHP 5.2.11, need to work around this somehow.
			$returnVal = $returnVal . chr( rand(65,90) );
		} //end for
		$redundancyQuery = "select sid from sessions where sid='$returnVal'";
		$redundancyQueryResult = mysql_query( $redundancyQuery );
		if( $redundancyQueryResult )
		{
			list( $sid ) = mysql_fetch_row( $redundancyQueryResult );
			if( $sid )
			{
				//this sid is a dup!
				return -1;
			} //end if
		} //end if
		return $returnVal;
	} //end generateSessionID()


	public function dump()
	{
		print "sid    :" . $this->sid . "\n";
		print "did    :" . $this->did . "\n";
		print "uid    :" . $this->uid . "\n";
		print "ip     :" . $this->ip . " (" . long2ip( $this->ip ) . ")\n";
		print "epoch  :" . $this->epoch . " (" . strftime( "%Y-%m-%d %T", $this->epoch ) . ")*\n";
		print "lastact:" . $this->lastact . " (" . strftime( "%Y-%m-%d %T", $this->lastact ) . ")*\n";
		print "* long forms are incorrect for non-integer values\n";
	} //end dump()


	public function dumpAsArray()
	{
		//TODO: write me
	} //end dumpAsArray()


	public function dumpAsJSON()
	{
		//TODO: write me
	} //end dumpAsJSON()
	

} //end Session
?>
