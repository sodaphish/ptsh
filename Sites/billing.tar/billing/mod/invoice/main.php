<?php
switch( $sub )
{
	case'invoices':
		switch($c)
		{
			case'add':
		
				if($date and $client)
				{
       					mysql_query("insert into invoice(date,client,note,status) values'$date','$client,'$note','$status')")or die(mysql_error() );
 
					print"$date $client $note $status";
				}else{
					include"frm_invoice_add.html";
					}
				break;

			case'edit':
				if($company_name)
				{
				//get customer from database
				}else{
					include"frm_customer_edit.html";
				}
				break;

			case'delete':
				break;
				
		default:
		}
	break;

	case 'customer':
		switch($c)
		{
			case'add':
				if($company_name and $address1 and $city)
				{
					mysql_query("insert into client(company_name,contact,address1,address2,city,state,zip,telephone,email,fax,www)values('$company_name','$contact','$address1','$address2','$city','$state','$zip','$telephone','$email','$fax','$wwww')")or die(mysql_error() );
				
				 print"$company_name $contact $address1 $address2 $city $state $zip $telephone $email $fax $www";  
			}else{
				include"frm_customer_add.html";
				}
				break;
				

			case'edit':
				break;

			case'delete':
				break;
		   default:
		}
		break;
	default:
		print"this is the default invoice module page.";
}
?>	
