<?php

function loadModConf( $modName ) 
{
	include "mod/$modName/conf.php";
}


function initModules( $modules )
{
	foreach( $modules as $mod )
	{
		loadModConf( $mod );
	}
}

?>
