import cookieserver
import time

def update(servers,i):
    for q in servers:
        q.updaterotation()
        q.spam()

def main():

    servers = []

##    #NYC CTF Server
##    q = cookieserver.CookieServer('74.63.52.42:27961', 'r3si5ucksc0ck')
##    q.set_Params(8, 12, 16, 2, 'CTF')
##    q.setupbots(4,6,8)
##    q.set_vspconfig('http://wildcatsclan.net/vsp/pub/themes/cookies/skillofip.php?config=cfg-botb.php')
##    q._skillkick = 14
##    q.set_skillname('Z^6 Best ^7of ^6Z')
##    servers.append(q)

    #FFA Server
    q = cookieserver.CookieServer('208.43.15.249:27960', 'Aft3rM4th')
    q.set_Params(10, 15, 20, 1, 'FFA')
    servers.append(q)

    #3rd Server
    q = cookieserver.CookieServer('208.43.15.201:27960', 'biodegradable')
    q.set_Params(12, 16, 20, 2, '3rd')
    servers.append(q)

##    #WC TDM Server
##    q = cookieserver.CookieServer('66.55.159.227:27960', 'n3v3rm0r3')
##    q.set_Params(10, 16, 22, 2, 'TDM')
##    q.setupbots(6,10,8)
##    servers.append(q)

##    #WC NO-Autos Server
##    q = cookieserver.CookieServer('63.209.35.46:27960', 'n3v3rm0r3')
##    q.set_Params(10, 16, 22, 2, 'NoA')
##    q.setupbots(6,10,8)
##    servers.append(q)

    #WC FTL Server
    q = cookieserver.CookieServer('74.117.237.77:27960', 'Aft3rM4th')
    q.set_Params(8, 12, 16, 2, 'FTL')
    q.setupbots(4,6,6)
    servers.append(q)

    #pRo BOMB Server
    q = cookieserver.CookieServer('74.63.69.35:27960', 'pootybooty')
    q.set_Params(6, 10, 14, 2, 'pRo')
    q.setupbots(1,7,4)
    servers.append(q)

    #West CTF Server
    q = cookieserver.CookieServer('216.18.220.211:27960', 'l34v3m34l0n3')
    q.set_Params(6, 10, 14, 2, 'WST')
    q.setupbots(6,8,8)
    q.set_skillname('^6Best ^7of ^6The')
    servers.append(q)


##    #TS Server
##    q = cookieserver.CookieServer('206.123.95.114:27960', 'r3si5ucksc0ck')
##    q.set_Params(6, 10, 14, 2, 'TS ')
##    #q.setupbots(1,7,4)
##    servers.append(q)

##    #Wave CTF Server
##    q = cookieserver.CookieServer('216.240.151.14:27960', 'r3si5ucksc0ck')
##    q.set_Params(10, 14, 20, 2, 'WAV')
##    q.setupbots(4,12,8)
##    servers.append(q)

##    #Wave CTF Server
##    q = cookieserver.CookieServer('216.18.220.211:27960', 'r3si5ucksc0ck')
##    q.set_Params(20, 24, 30, 2, 'WAV')
##    q.setupbots(10,16,12)
##    servers.append(q)

##    #NYC CTF Server
##    q = cookieserver.CookieServer('74.63.52.42:27961', 'r3si5ucksc0ck')
##    q.set_Params(20, 24, 30, 2, 'NYC', 'bigtext \"^2/CONNECT ^6ZoD.^2midnightgaming.^6net\"')
##    q.setupbots(10,16,12)
##    servers.append(q)


    i = 0
    while 1<2:
        print '----------------------------------------------'
        update(servers,i)
        time.sleep(100)
        i += 1

if __name__ == '__main__':
	main()

#static debugging code
def testplayercount():
    q = cookieserver.CookieServer('63.211.110.238:27960', 'mdizzymd')
    print 'Red %s, Blue %s' % (q.num_red(), q.num_blue())

def testplayercountcycle():
    q = cookieserver.CookieServer('216.240.151.14:27960', 'popo4shosho')
    q.rcon("cyclemap")
    print 'Red %s, Blue %s' % (q.num_red(), q.num_blue())

def testbots():
    #q = cookieserver.CookieServer('208.43.92.134:27960', 'kis5m3imiri5h')
    q = cookieserver.CookieServer('68.232.168.216:27960', 'n3v3rm0r3')
    q.set_Params(20, 21, 22, 2, 'FTL')
    q.setupbots(3,7,7)
    q.updaterotation()

def testupdate():
    q = cookieserver.CookieServer('208.43.15.249:27960', 'r3si5ucksc0ck')
    q.updaterotation()

def testRCONupdate():
    q = cookieserver.CookieServer('74.63.52.42:27961', 'r3si5ucksc0ck')
    #q = cookieserver.CookieServer('64.34.165.146:27965', 'r3si5ucksc0ck')
    q.rcon_update()
    q.rcon_output()

def testQportFilter(qport = '1337'):
    #q = cookieserver.CookieServer('208.43.15.249:27960', 'r3si5ucksc0ck')
    q = cookieserver.CookieServer('208.43.15.249:27960', 'r3si5ucksc0ck')
    q.qport_filter(qport)

def testBan(ip):
    #q = cookieserver.CookieServer('208.43.15.249:27960', 'r3si5ucksc0ck')
    q = cookieserver.CookieServer('208.43.15.249:27960', 'r3si5ucksc0ck')
    q.banplayer(ip)

def testclientcount():
    q = cookieserver.CookieServer('208.43.15.249:27960', 'r3si5ucksc0ck')
    print 'Clients %s' % q.num_clients()

def testPlayers():
    q = cookieserver.CookieServer('208.43.15.249:27960', 'r3si5ucksc0ck')
    q.get_Players()

def testgametype():
    q = cookieserver.CookieServer('208.43.15.249:27960', 'r3si5ucksc0ck')
    print 'G-Type: %s' % q.get_gametype()

def testADspam():
    q = cookieserver.CookieServer('66.207.162.130:27960', 'r3si5ucksc0ck')
#    q.set_Params(8, 14, 32, 2, 'TEST', 'say ^3TeamSpeak @ civilizedpub.com')
    q.set_Params(8, 14, 32, 2, 'TEST')
    q.spam()

def testupdateSkills():
    q = cookieserver.CookieServer('74.63.52.42:27961', 'r3si5ucksc0ck')
    #q = cookieserver.CookieServer('208.43.15.249:27960', 'r3si5ucksc0ck')
    q.set_Params(6, 10, 14, 2, 'CTF')
    q._skillkick = 14
    q.set_vspconfig('http://wildcatsclan.net/vsp/pub/themes/cookies/skillofip.php?config=cfg-botb.php')
    q.set_skillname('>Z<^6Best ^7of ^6>Z<')
    q._ignoreCheck = True
    q.updaterotation()

def testPerDiff():
    q = cookieserver.CookieServer('74.63.52.42:27961', 'r3si5ucksc0ck')
    q.redPercentDiff()

def testkickreason():
    q = cookieserver.CookieServer('74.63.52.42:27961', 'r3si5ucksc0ck')
    q.kickReason(0, 'nobody likes you and we are testing skill filter', 4)

def testserverskill():
    q = cookieserver.CookieServer('74.63.52.42:27961', 'r3si5ucksc0ck')
    q.rcon_update()
    q.set_vspconfig('http://wildcatsclan.net/vsp/pub/themes/cookies/skillofip.php?config=cfg-botb.php')
    q.get_skills()
    print 'avg: %s' % q.averageSkill()
    p = q.minSkill()
    if( p == 0):
        print 'problem finding lowest' % q.averageSkill()
    else:
        print 'lowest skill %s, name: %s, slot: %s, ip %s' % (p.skill, p.name, p.slot, p.address)

def testmatchmode():
    q = cookieserver.CookieServer('66.207.162.130:27961', 'r3si5ucksc0ck')
    (v,l) = q.get_matchmode()
    print 'MatchMode: %s, %s' % (v,l)
    print 'isMatchMode: %s' % q.is_matchmode()