import pyquake3
import urllib
import time
import re

##class Player:
##    def __init__(self, slot, name, frags, deaths, ping, address=None):
##        self.slot = slot
##        self.name = name
##        self.frags = frags
##        self.deaths = deaths
##        self.ping = ping
##        self.address = address
##    def __str__(self):
##        return self.name
##    def __repr__(self):
##        return str(self)

class CookieServer(pyquake3.PyQuake3):
    _playercount = -1
    _rotation = 0
    _switchcount1 = 12
    _switchcount2 = 18
    _switchcount3 = 24
    _hysteresis = 2
    _servername = 'noname'
    _gametype = -1
    _map = ''
    _bots = False
    _minbots = -1
    _minclients = -1
    _ads = False
    _adMessage = 'Insert Message Here'
    _kickbots = 99
    _vspconfig = ''
    _reds = ''
    _blues = ''
    _skillkick = 99
    _skillname = ''
    _ignoreCheck = False
    _perDiff = 0

##    def get_Players(self):
##        try:
##            cmd, data = self.rcon('players')
##            print 'raw players data \n%s' % data
##            lines = data.split('\n')
##        except:
##            raise Exception('Failed to Get Players INFO')

    #------------Server Polling
    def num_clients(self): #assumes rconupdate has been called
        try:
            #cmd, data = self.rcon('status')
            #print 'DATA: %s' % data
            #lines = data.split('\n')
            #print 'lines: %s status %s' % (len(lines), data)
            #return len(lines) - 5
            #self.update()
            return len(self.players)
        except:
            raise Exception('Problem getting Num CLients')

    def get_reds(self):
        try:
            cmd, data = self.rcon('g_redteamlist')
            #print 'raw red data %s' % data
            #print 'data begin %s' % data[0:9]
            if data[0:9] == 'broadcast' : return ''
            slots = data[20:(len(data)-17)]
            #print 'len: %s Str: %s Slots: %s Len(Slots): %s' % ( len(data), data, slots, len(slots))
            return slots
        except:
            raise Exception('Problem getting Red Team')

    def get_blues(self):
        try:
            cmd, data = self.rcon('g_blueteamlist')
            #print 'raw blue data %s' % data
            if data[0:9] == 'broadcast' : return ''
            slots = data[21:(len(data)-17)]
            #print 'len: %s Str: %s Slots: %s Len(Slots): %s' % ( len(data), data, slots, len(slots))
            return slots
        except:
            raise Exception('Problem getting Blue Team')

    def num_red(self):
        try:
            self._reds = self.get_reds()
            return len(self._reds)
        except:
            raise Exception('Problem getting Red Team Size')

    def num_blue(self):
        try:
            self._blues = self.get_blues()
            return len(self._blues)
        except:
            raise Exception('Problem getting Blue Team Size')

    def get_gametype(self):
        try:
            cmd, data = self.rcon('mapname')
            mapinfo = data.split('"')
            mapinfo = mapinfo[3].split('^7')
            #print 'Map: %s ' % mapinfo[0]
            self._map = mapinfo[0]

            cmd, data = self.rcon('g_gametype')
            lines = data.split('"')
            lines = lines[3].split('^7')
            self._gametype = int(lines[0])
            return int(lines[0])
        except:
            raise Exception('Problem getting GameType')

    def get_matchmode(self):
        return self.get_variable("g_matchmode")

    def is_matchmode(self):
        (v,l) = self.get_matchmode()
        return (v>0 or l>0)

    def get_variable(self, varname):
        try:
            cmd, data = self.rcon(varname)
            #print 'get_variable raw %s' % data
            lines = data.split('\n')
            info = lines[0].split('"')
            #print 'get_variable split %s len: %s' % (lines, len(lines))
            v = info[3].split('^7')
            if len(lines) > 2: #latched values
                latched = lines[1].split('"')
                #print 'latched split %s ' % latched
                latched = latched[1]
            else: latched = v[0]
            #print 'v %s l %s' % (v[0], latched)
            return (int(v[0]) , int(latched))
        except:
            raise Exception('Problem getting GameType')


#------------------Rotation Manager
    #setting rotations
    def setrotation(self, newrotation):

        if newrotation == self._rotation and newrotation != 0:
            print '%s Rotation not changed %s Players %s Rotation %s' % (self._servername, self._playercount, newrotation, self._map)
            return None

        if self._gametype == 0 or self._gametype == 4 or self._gametype == 8: #FFA or TS or BOMB
            if newrotation == 0:
              rotcommand = 'exec zero'
            elif newrotation == 1:
              rotcommand = 'exec small'
            elif newrotation == 2:
              rotcommand = 'exec medium'
            elif newrotation == 3:
              rotcommand = 'exec big'
            elif newrotation == 4:
              rotcommand = 'exec giant'
            else:
              print 'Error: Invalid newrotation passed to setrotation.'
              return None
        else:
            if newrotation == 0:
              rotcommand = 'exec zero'
            elif newrotation == 1:
              rotcommand = 'exec empty'
            elif newrotation == 2:
              rotcommand = 'exec normal'
            elif newrotation == 3:
              rotcommand = 'exec full'
            elif newrotation == 4:
              rotcommand = 'exec max'
            else:
              print 'Error: Invalid newrotation passed to setrotation.'
              return None

        try:
            self.rcon(rotcommand)
            print '%s %s Players, %s config %s' % (self._servername,self._playercount,rotcommand, self._map)
            self._rotation = max(1,newrotation)
        except:
            print 'RCON failed to execute config in Rotation Manager'

    #set new rotation based on number of players
    def checkrotation(self, numplayers, skip=False):
        if (skip):
            print 'rotation update skiped'
            return

        lpc = self._playercount
        self._playercount = numplayers

        if self._rotation < 2: #small
            if numplayers >= self._switchcount2:
                newrotation = 3
            elif numplayers >= self._switchcount1 :
                newrotation = 2
            else:
                if ( lpc == 0 and numplayers == 0):
                    newrotation = 0
                    self._playercount = 6
                else:
                    newrotation = 1
        elif self._rotation == 2: #medium
            if numplayers >= self._switchcount3:
                newrotation = 4
            elif numplayers >= self._switchcount2:
                newrotation = 3
            elif numplayers < self._switchcount1 - self._hysteresis:
                newrotation = 1
            else:
                newrotation = 2
        elif self._rotation == 3: #large
            if numplayers >= self._switchcount3:
                newrotation = 4
            elif numplayers < self._switchcount2 - self._hysteresis:
                newrotation = 2
            else:
                newrotation = 3
        else: #giant
            if numplayers < self._switchcount3 - self._hysteresis:
                newrotation = 3
            else:
                newrotation = 4

        self.setrotation(newrotation)

    #update rotations
    def updaterotation(self):
        waitCookieCycle = 50
        try:
            if self.is_matchmode():
                print '%s MatchMode, No Changes' % self._servername
				return waitCookieCycle
            else:
                self.qport_filter('1337') #must be called before anything that looks at players (adjustbots, skill operations)

                #getskills
                if self._vspconfig != '': #VSP integration
                    try:
                        self.get_skills()
                    except:
                        print 'ERROR: unable to access VSP dbase'
                        return 15

                #count actives
                if self.get_gametype() == 0: #FFA
                    x = self.num_clients()
                else:
                    x = int(self.num_red() + self.num_blue())

                #bots
                if self._bots:
                    if self.adjustbots(x): #reget teams
                        if self._gametype == 0: #FFA
                            x = self.num_clients()
                        else:
                            x = int(self.num_red() + self.num_blue())

                if x >= 12: waitCookieCycle = 35
                if x >= 14: waitCookieCycle = 25

                #assumes qport filter called rcon_update
                if self._vspconfig != '':
                    (r,b, nr, nb, ns) = self.teamAverageSkills()
                    avg = int((r*nr + b*nb)/(nr+nb))  #self.averageSkill()
                    missing = self.missingSkill()
                    if missing > 0:
                        print 'AVG-skill: %s(%s), RED: %s(%s), BLUE: %s(%s), diff: %s' % (avg, missing, r, nr, b, nb, r*nr - b*nb)
                    else:
                        print 'AVG-skill: %s, RED: %s(%s), BLUE: %s(%s), diff: %s' % (avg, r, nr, b, nb, r*nr - b*nb)
                    p = self.minSkill()

                    if self._skillname != '': self.setServerName(avg, x)

                    if( p == 0):
                        print 'problem finding lowest'
                        waitCookieCycle = 10
                    else:
                        kickThresh = (0.4 + 0.10*(x+(ns/2)-self._skillkick) + 0.05 * (x%2) )
                        if x+(ns/2)-self._skillkick > 0.5: kickThresh += 0.1
                        kickThresh *= avg
                        #print 'DEBUG: x: %s, kick: %s, miss: %s, lowest skill %s (%s %s), name: %s, slot: %s' % (x, self._skillkick, missing, p.skill, int(kickThresh), self.pingPenalty(p),p.name, p.slot)
                        print 'lowest skill %s (%s %s), name: %s, slot: %s' % (p.skill, int(kickThresh), self.pingPenalty(p),p.name, p.slot)

                        if( int(p.skill) == 0):
                            print 'inappropriate skill value, no kick'
                        else:
                            kicked = self.kickWeakest(p, kickThresh, avg)
                            if kicked == True:
                                waitCookieCycle = waitCookieCycle / 2
                                self.players.remove(p)
                                if p.team == 'RED':
                                    r = ((r * nr) - int(p.skill))/(nr - 1)
                                    nr -= 1
                                    x -= 1
                                elif p.team == 'BLUE':
                                    b = ((b * nb) - int(p.skill))/(nb - 1)
                                    nb -= 1
                                    x -= 1
                            else: self.kickSpec(ns, x, avg)

                #checkrotation   #print 'DEBUG %s Total Players' % x
                x = max(x, self._playercount/2 - 1)
                self.checkrotation(x, self._ignoreCheck)

                #autobalance
                if self._vspconfig != '' and x > 2:
                    self.autobalance(nr, r, nb, b, avg)

                return waitCookieCycle
        except:
            print '%s Rotation Update Failed' % self._servername
            return 5

    def pingPenalty(self, p):
        return min(600, int(p.ping) - 50)

    def closestSkill(self, target, team):
        print 'DEBUG: closest skill %s %s' % (target, team)
        distance = 99999
        result = False
        for p in self.players:
            if( p.team == team and abs(int(p.skill)-target)<distance ):
                distance = abs(int(p.skill)-target)
                result = p
        if result == False: print 'Unable to find closestSkill'
        return result

    def autobalance(self, nr, r, nb, b, avg):
        #bias = 1000.0 * self.redPercentDiff()
        bias = avg * self.redPercentDiff()
        if nr > nb:
            if (bias > 0 and (nr * r - nb * b + bias > avg * 1.25)) or (nr - nb > 1):
                try:
                    diff = nr-nb
                    if diff == 1:
                        diff = (nr * r - nb * b + 0.75 * avg )/2
                    else:
                        diff = (nr * r - nb * b + bias) / diff
                    bal = self.closestSkill(diff, 'RED')
                    rconmsg = 'Say ^4   Keep Teams Balanced or CookieBot Will, suggest ^7%s' % bal.name
                    self.rcon(rconmsg)
                    time.sleep(10)
                    rconmsg = 'forceteam %s a' % bal.slot
                    print 'DEBUG: %s BIAS, forcing BLUE %s %s %s' % (bias, bal.slot, bal.name, bal.skill)
                    self.rcon(rconmsg)
                except:
                    print 'Error balancing teams RED'
        if nr < nb:
            if (bias < 0 and (nr * r - nb * b + bias < -avg * 1.25)) or (nr - nb < -1):
                try:
                    diff = nr-nb
                    if diff == -1:
                        diff = (nb * b - nr * r + 0.75 * avg)/2
                    else:
                        diff = (nr * r - nb * b + bias) / diff
                    bal = self.closestSkill(diff, 'BLUE')
                    rconmsg = 'Say ^1   Keep Teams Balanced or CookieBot Will, suggest ^7%s' % bal.name
                    self.rcon(rconmsg)
                    time.sleep(10)
                    rconmsg = 'forceteam %s a' % bal.slot
                    print 'DEBUG: %s BIAS, forcing RED %s %s %s' % (bias, bal.slot, bal.name, bal.skill)
                    self.rcon(rconmsg)
                except:
                    print 'Error balancing teams BLUE'

    def kickSpec(self, ns, actives, avg):
        try:
            if ns > 2 and ns + actives > 1 + self._skillkick:
                #too many specs, kick the lowest skilled spec
                toKick = self.minSpecSkill()
                print 'kicking spec %s from server' % toKick.slot
                reason1 = 'Game Difficulty: %s, Your Skill: %s.  team-zod.com for STATs.' % (avg, toKick.skill)
                reason2 = 'SPEC FILTER. No More then 2 specs allowed on the server.'
                self.kickReason(toKick.slot, reason1, reason2, 6)
                return True
        except:
            print 'error kicking a SPEC'
            return False

    def kickWeakest(self, p, kickThresh, avg):
        try:
            if (int(p.skill) < kickThresh ): #kick a player
                print 'kicking player %s from server' % p.slot
                reason1 = 'Game Difficulty: %s, Your Skill: %s.  team-zod.com for STATs.' % (avg, p.skill)
                #reason2 = 'AUTO-SKILL FILTER. Thank You for Playing. Try Again Later.  '
                reason2 = 'AUTO-SKILL FILTER. Try our West Coast Server.  ^6connect 216.18.220.211'
                self.kickReason(p.slot, reason1, reason2, 6)
                return True
            elif ( p.team != 'SPEC' and int(p.skill) < kickThresh + self.pingPenalty(p)): #kick a high ping player
                print 'kicking high-ping player %s from server' % p.slot
                if int(p.ping) > 200:
                    reason1 = 'Your PING: %s, Is above tolerance at this time' % int(p.ping)
                    #reason2 = 'PING FILTER. Thank You for Playing. Comeback Later.'
                    reason2 = 'PING FILTER. Try our West Coast Server.  ^6connect 216.18.220.211'
                else:
                    reason1 = 'Game Difficulty: %s, Your Skill: %s.  team-zod.com for STATs.' % (avg, p.skill)
                    #reason2 = 'AUTO-SKILL FILTER. Thank You for Playing. Try Again Later'
                    reason2 = 'AUTO-SKILL FILTER. Try our West Coast Server.  ^6connect 216.18.220.211'
                self.kickReason(p.slot, reason1, reason2, 6)
                return True
            else:
                return False
        except:
            print 'error kicking player %s from server' % p.slot
            return False

    def skilToName(self, value):
        if value < 1000: return ' NuBs'
        if value < 1400: return ' Rest'
        if value < 1800: return ' Best'
        if value < 2200: return ' PrOs'
        return ' GoDs'


    def setServerName(self, avg, numplayers):
        try:
            if avg == 1000 or numplayers < 8:
                suf = ' Best'
            else:
                suf = '%s ^6%s' % (self.skilToName(avg), avg)

            newname = 'sv_hostname \"%s^7%s\"' % (self._skillname, suf)
            #newname = 'sv_hostname \"%s ^6%s Diff\"' % (self._skillname, avg)
            #print 'DEBUG: newname %s' % newname
            self.rcon(newname)
        except:
            print 'failure to rename server'

     #set skill name for dynamic Name
    def set_skillname( self, skillname):
        self._skillname = skillname

    #set switch params
    def set_Params(self, s1, s2, s3, h=2, sname='noname', admessage=''):
        self._servername = sname
        self._switchcount1 = s1
        self._switchcount2 = s2
        self._switchcount3 = s3
        self._hysteresis = h
        if admessage == '':
            self._ads = False
        else:
            self._ads = True
            self._adMessage = admessage

    def spam(self):
        if self._ads == True:
            try:
                self.rcon(self._adMessage)
            except:
                print 'AD-SPAM Failed'

    def retarded(self):
        print 'whats wrong?'


    def redPercentDiff(self):
        try:
            cmd, pResult = self.rcon('players')
            #print '%s' % pResult
            pResult = pResult.split('\n')
            #print '%s' % pResult
            pResult = pResult[2]
            #print '%s' % pResult
            pResult = pResult.split(' ')
            #print '%s' % pResult
            red = pResult[1].split(':')
            blue = pResult[2].split(':')
            red = red[1]
            blue = blue[1]
            #print '%s %s' % (red, blue)
            result = 2 * (float(red) + 2) / (float(red) + float(blue) + 4) - 1
            print 'BIAS: %s' % result
            self._perDiff = result
            return result
        except:
            return self._perDiff

    #--------------RCON Update functions
    def rcon_output(self):
        for player in self.players:
            print '%s, slot %s, score %s, ping %s, addr: %s, qport %s' % (player.name, player.slot, player.frags, player.ping, player.address, player.qport)

    #--------------1337 Port Filter
##    def ban_player(self, p):
##        self.rcon("addip " & p.address  )

    def qport_filter(self, illegalPort = '1337'):
        self.rcon_update()
        for player in self.players:
            if player.qport == illegalPort and player.address != 'bot':
                print 'Hacker FOUND on %s server.  %s, slot %s, addr: %s' % (self._servername , player.name, player.slot, player.address)
                banAdd = player.address.split(':')
                self.banplayer(banAdd[0])
                self.kickplayer(player.slot)

    def set_vspconfig(self, cfg):
        self._vspconfig = cfg

    #assume rcon_update has been run
    def get_skills(self):
        reg = re.compile( '\W')
        colors = re.compile( '\^.')
        url = self._vspconfig
        for p in self.players:
            rname = colors.sub('',p.name)
            rname = reg.sub('.',rname)
            url += '&ip' + p.slot+'='+p.address +  '&name' + p.slot + '=' + rname

        #print 'DEBUG: url = %s' % url
##        for p in self.players:
##            url += '&name' + p.slot + '=' + rname

        f = urllib.urlopen(url)
        # Read from the object, storing the page's contents in 's'.
        s = f.read()
        s = s.replace("\r\n", "")
        s = s.replace(", ''", "")
        #print 'DEBUG %s'% s
        s = s.split(',')
        #print 'DEBUG %s'% s
        for x in s:
            data = x.split(' ')
            for pl in self.players:
                if pl.slot == data[0]:
                    pl.skill = data[1]
                    #print 'DEBUG Slot %s skill %s' % (pl.slot, pl.skill)

    def minSpecSkill(self):
        lowest = 99999
        for p in self.players:
            if p.team == 'SPEC':
                if int(p.skill)<lowest :
                    lowest = int(p.skill)
                    who = p
        if lowest != 99999:
            return who
        return 0

    def minSkill(self):
        lowest = 99999
        for p in self.players:
            if p.team == 'SPEC':
                if (int(p.skill)<lowest and int(p.skill) !=1000):
                    lowest = int(int(p.skill))
                    who = p
            else:
                if int(p.skill) - self.pingPenalty(p) <lowest and (int(p.skill)!=1000 or int(p.ping)>200 ):
                    lowest = int(int(p.skill) - self.pingPenalty(p))
                    who = p
        if lowest != 99999:
            return who
        return 0

##    def playerOfSlot(self, slot):
##        for p in self.players:
##            if p.slot == slot: return p
##        return 0

    def teamAverageSkills (self):
        redsum = 0
        bluesum = 0
        redcount = 0
        bluecount = 0
        speccount = 0
        for p in self.players:
            ascii = '%c' % (int(p.slot) + 65)
            if self._reds.find(ascii) != -1:
                redsum += int(p.skill)
                redcount += 1
                p.team = 'RED'
            elif self._blues.find(ascii) != -1:
                bluesum += int(p.skill)
                bluecount += 1
                p.team = 'BLUE'
            else: #spec
                speccount += 1
                p.team = 'SPEC'
        if redcount == 0:
            redcount =1
            redsum = 1000
        if bluecount == 0:
            bluecount =1
            bluesum = 1000
        return (int(redsum/redcount), int(bluesum/bluecount), redcount, bluecount, speccount)

    def averageSkill(self):
        skillsum = 0
        count = 0
        for p in self.players:
            skillsum += int(p.skill)
            count += 1
        if count == 0: return 1000
        return skillsum/count

    #count the number of players with unknown skill
    def missingSkill(self):
        count = 0
        for p in self.players:
            if int(p.skill) == 1000: count += 1
        return count

    def kickReason(self, slot, reason1, reason2, delay):
        rconmsg = 'tell %s %s' % (slot, reason1)
        self.rcon(rconmsg)
        rconmsg = 'tell %s %s' % (slot, reason2)
        self.rcon(rconmsg)
        time.sleep(delay)
        #print 'DEBUG: KICKing disabled'
        self.rcon('kick %s' % slot)

    def banplayer(self, ip):
        try:
            cmd, data = self.rcon('addip ' + ip)
            print 'banning: %s' % data
        except:
            print 'failed to ban'

    def kickplayer(self, slot):
        try:
            self.rcon('kick ' + slot)
            print 'kicking %s' % data
        except:
            print 'failed to kick'

    #----------Bot Foolishness
    def setupbots(self, minbots, kickthresh, minclients):
        self._bots = True
        self._minbots = minbots
        self._minclients = minclients
        self._kickbots = kickthresh

    def adjustbots(self, numplayers):
        #assumes rcon update has been called
        if numplayers < self._minbots:
            try:
                self.rcon('vstr addredbot')
            except:
                print 'addabot Failed'
        elif self.num_clients() < self._minclients:
            try:
                self.rcon('vstr addspecbot')
            except:
                print 'addspecbot Failed'
        else:
            numbots = 0
            for p in self.players:
                if p.address == 'bot':
                    numbots += 1

            if numbots > 0:
                if self.num_clients() > self._minclients:
                    for p in reversed(self.players):
                        if p.address == 'bot':
                            print 'Kick Bot: %s %s %s' % (p.name, p.slot, p.address)
                            self.rcon('kick %s' % p.slot)
                            return True
##                if numplayers >= self._kickbots:
##                    try:
##                        self.rcon('kick allbots')  #assumes server has addabot script
##                        #self.updaterotation()
##                    except:
##                        print 'kick bots Failed'
        return False
