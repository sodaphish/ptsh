import cookieserver
import time

def update(servers,i):
    for q in servers:
        result = q.updaterotation()
        q.spam()


def main():

    servers = []

    #NYC CTF Server
    q = cookieserver.CookieServer('74.63.52.42:27961', 'l34v3m34l0n3')
    #q.set_Params(8, 12, 16, 2, 'CTF')
    q.set_Params(6, 10, 14, 2, 'CTF')
    q.setupbots(6,8,8)
    q.set_vspconfig('http://wildcatsclan.net/vsp/pub/themes/cookies/skillofip.php?config=cfg-botb.php')
    q._skillkick = 14
    q.set_skillname('Z^6 Best ^7of ^6Z')

    i = 0
    while 1<2:
        print '----------------------------------------------'
        sleeptime = q.updaterotation()
        print 'Sleep %s' % sleeptime
        time.sleep(sleeptime)
        i += 1

if __name__ == '__main__':
	main()