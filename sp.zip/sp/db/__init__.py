from Global import cfg
import xml
__all__ = []

import sys

try:
    from sp.base import Exceptions
except:
    print "Install sp into sys.path()"
    sys.exit(2)

    
    

'''__EOF__'''