''' 
cfg.py - the configuration for scout
'''
timeout = .75
byteCount = 256
verbose = 0
catalogFile = "/home/cjsteele/Desktop/Scout-0.0.3/default.cat"
