'''

pyScout v. 0.0.3 - a threaded port scanner with application identification engine...
	(C)opyright 2006, C.J. Steele, all rights reserved.  Portions copyright
	other persons, per following:
	* The threaded portscanning code is based on pyScan by Lawrence Oluyede.
		per aspn.activstate.com recipe #286240
	* some of the banner signatures are based on the datafiles that ship with
		THC-Amap

'''
from TCPBanner import TCPBanner
from Catalog import Catalog
import socket as sk
import sys
import cfg
import threading

cfg.verbose = 1
MAX_THREADS = 50

def usage():
    print "pyScout 0.0.3"
    print "usage: pyScout <host> [start port] [end port]"

    
class Scanner(threading.Thread):
	def __init__(self, host, port):
		threading.Thread.__init__(self)
		self.host = host
		self.port = port
		self.sd = sk.socket(sk.AF_INET, sk.SOCK_STREAM)

	def run(self):
		try:
			self.sd.connect( self.host, self.port )
			banner = TCPBanner( self.host, self.port )
			service = cat.matchBanner( banner )
			if service == "unknown":
				print "%s:%s -> %s (%s)" % ( self.host, self.port, service, banner.banner )
			else:
				print "%s:%s -> %s" % ( self.host, self.port, service )
			self.sd.close()
		except: 
			pass

class pyScan:
	def __init__(self, args=[]):
	   	self.args = args
   		self.start, self.stop = 1, 1024
   		self.host = ""

   		if len(self.args) == 4:
   			self.host = self.args[1]
   			try:
   				self.start = int(self.args[2])
   				self.stop = int(self.args[3])
   			except ValueError:
   				usage()
			   	return
	   	if self.start > self.stop:
   			usage()
		   	return
	
   		try:
		   	sk.gethostbyname(self.host)
   		except:
		   	print "hostname '%s' unknown" % self.host
	
   		self.scan(self.host, self.start, self.stop)

   	def scan(self, host, start, stop):
   		self.port = start
   		while self.port <= stop:
   			while threading.activeCount() < MAX_THREADS:
   				Scanner(host, self.port).start()
				self.port += 1
        
if __name__ == "__main__":
	cat = Catalog()
	cat.readCatalog( cfg.catalogFile )
   	pyScan(sys.argv)
