'''
Banner.py -- Python class for grabbing TCP application banners
	(C)opyright 2006, C.J. Steele, all rights reserved.

get timeoutsocket module from http://www.timo-tasi.org/python/timeoutsocket.py

'''
import cfg 
import socket
import timeoutsocket

class TCPBanner:

	host = "localhost"
	port = 0
	banner = ""
	error = ""

	def __init__( self, host, port ):
		s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		s.set_timeout( cfg.timeout )
		try:
			s.connect((host, port))
		except:
			self.error = "failed to connect"

		if not self.error:
			# we send garbage to get the protocol talking...
			# TODO: this is where we'd hook in if we wanted to use different triggers like AMap
			# 	...this is what the PromptCatalog class will be for, ultimately.
			s.send( "\001\012\012\012" )
			output = ""
			byteCount = 0
			while( byteCount <= cfg.byteCount ):
				data = ""
				try: 
					data = s.recv(1)
				except Exception:
					# this will occur b/c a timeout, end of data, or other anamolous thing (garbage data back, etc.)
					break
			
				byteCount = byteCount + 1
				output += data 
			self.banner =  output
			s.close()
		
''' EOF '''
