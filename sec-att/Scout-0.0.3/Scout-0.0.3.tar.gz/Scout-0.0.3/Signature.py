'''
Signature.py - a container class for handling application banner signatures
	(C)opyright 2006, C.J. Steele, all rights reserved.

'''
class Signature:

	sigLabel = ""
	sigPattern = ""

	def __init__( self, label, pattern ):
		if label != "":
			self.sigLabel = label
		else:
			raise Exception ( 'Signature', "invalid label" )

		if pattern != "": 
			self.sigPattern = pattern
		else:
			raise Exception ( 'Signature', "invalid pattern" )


''' EOF '''
