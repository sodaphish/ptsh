#!/usr/bin/python
'''

Scout.py - a signature-based TCP banner grabber
	(C)opyright 2006, C.J. Steele, all rights reserved.

'''

import sys
import cfg
from TCPBanner import TCPBanner
from Catalog import Catalog

cfg.verbose=0

cat = Catalog()
cat.readCatalog( cfg.catalogFile )

if len( sys.argv ) != 3:
	print "Usage: ./scout.py <target> <port>"
	sys.exit(1)

host = sys.argv[1]
port = int(sys.argv[2])

banner = TCPBanner( host, port )
service = cat.matchBanner( banner )
if service != "unknown":
	if cfg.verbose:
		print "%s:%s -> %s (%s)" % ( host, port, service, banner.banner )
	else:
		print "%s:%s -> %s" % ( host, port, service )

''' EOF '''
