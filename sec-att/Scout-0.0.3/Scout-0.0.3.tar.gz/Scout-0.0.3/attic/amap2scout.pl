#!/usr/bin/perl
use strict;

open( IN, "./amap.resp" ) or die( "$!" );
while( <IN> )
{
	chomp();
	#echo:http-get:::^GET / HTTP/1.0
	my( $a, $b, $c, $d, $e ) = split( /\:/, $_, 5 );
	print "$a|$e\n";
}
close( IN );
