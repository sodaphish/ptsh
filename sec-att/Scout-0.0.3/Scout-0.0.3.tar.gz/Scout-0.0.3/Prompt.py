'''
Prompt.py - a container class for handling the prompts needed to identify an application 
	(C)opyright 2006, C.J. Steele, all rights reserved.

'''
class Prompt:

	promptLabel = ""
	promptPattern = ""

	def __init__( self, label, pattern ):
		if label != "":
			self.promptLabel = label
		else:
			raise Exception ( 'Prompt', "invalid label" )

		if pattern != "": 
			self.promptPattern = pattern
		else:
			raise Exception ( 'Prompt', "invalid pattern" )


''' EOF '''
