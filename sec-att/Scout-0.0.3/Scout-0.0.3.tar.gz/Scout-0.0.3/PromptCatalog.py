'''

PromptCatalog.py - a Catalog of Prompts for use with Scout.
	(C)opyright 2006, C.J. Steele, all rights reserved.

'''
from Prompt import Prompt 
import os.path
import re

class ProtmpCatalog:

	catalog = []
	catalogFile = ""

	def __init__( self ):
		self.catalog = []
	
	def readCatalog( self, filename ):
		if os.path.isfile( filename ):
			# read in the catalog file!
			self.catalogFile = filename
			f = open( filename )
			line = f.readline()
			while( line ):
				line = line.rstrip()
				''' exclude lines that start with a Hash-symbol and those that are blank-lines '''
				p = re.compile( "^\#" )
				q = re.compile( "^$" )
				if not p.match( line ) and not q.match( line ):
					( label, pattern ) = line.split( '|', 2 ) 
					prompt = Prompt( label, pattern)
					self.catalog.append( prompt )
				line = f.readline()
		else:
			raise Exception ( 'CatalogErr', 'Couldn\'t read catalog file.' )


	def dumpCatalog( self ):
		for c in self.catalog:
			print c.promptLabel, " ", c.promptPattern


	def matchBanner( self, b ):
		for c in self.catalog:
			p = re.compile( c.promptPattern )
			if p.search( b.banner ):
				return c.promptLabel
		return "unknown"


''' EOF ''' 
