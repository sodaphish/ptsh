#!/bin/sh

rpm -Uvh /home/csteele/downloads/procps-2.0.7-11.i386.rpm --force
rpm -Uvh /home/csteele/downloads/fileutils-4.1-4.i386.rpm --force
