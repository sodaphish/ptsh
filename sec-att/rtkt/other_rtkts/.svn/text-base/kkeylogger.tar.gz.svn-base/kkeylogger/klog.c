/*
 * (C)opyright 2002, Corey J. Steele, all rights reserved.
 */

#define MODULE
#define __KERNEL__

#ifdef MODVERSIONS
#include <linux/modversions.h>
#endif

#define VER_MAJOR 0
#define VER_MINOR 0
#define VER_PATCH 1

#include <linux/kernel.h> 
#include <linux/module.h>
#include <stdio.h>
#include <string.h>

extern void *sys_call_table[];
char *logfile;

int get_logfile()
{
	char *template = "klog.XXXXXX"; 
	if( mktemp( template ) )
	{
		strcpy( logfile, template );
		return 1; 
	}
	/* else */
	return 0;
}

int init_module()
{
	if( get_logfile() )
	{

		printk( "klog %d.%d.%d\n", VER_MAJOR, VER_MINOR, VER_PATCH );
		printk( "logfile = %s\n", logfile );
		return 0;
	} else 
	{
		printk( "couldn't get the log file!\n" );
		return 1;
	}
}

void cleanup_module()
{
	printk( "unloading...\n" );
}
